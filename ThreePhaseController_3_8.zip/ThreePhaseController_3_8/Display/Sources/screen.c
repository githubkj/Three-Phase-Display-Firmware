#include "screen.h"
#include "icon.h"
#include "digit.h"
#include "OLED.h"
#include "PE_Types.h"
#include "button.h"
#include "menu.h"
#include "mainMenu.h"
#include "userMenu.h"
#include "serviceMenu.h"
#include "text.h"
#include "Events.h"
#include "display_UART.h"
#include "stdbool.h"
#include "displayMemory.h"

uint16_union modbus_ro_reg_rcv[RO_REG_LEN];					// read only registers controller copy
byte modbus_rw_coil_rcv[RW_COIL_LEN/8+1];					// read/write coils controller copy

// Check All Pixels
void turnOnAllPixels(void)
{
	fillDisplay();
	updateScreen = true;
	TI1_checkPixelsTimer_Flag = true;
}

void mainScreen()
{
	_Bool probe2IsPresent = modbus_rw_coil_rcv[PROBE2_PRESENT] & PROBE2_PRESENT_F;
	if (pressedOK && !buttonHold) // only change screen once for one press, ignore the hold
	{
		pressedOK = false;
		// Turn off alarm timer and clear its counter
		TI1_alarmTimer_Flag = false;
		TI1_alarmTimer = 0;
		if (currentPosition.lineNumber == INLET_LINENUM)
		{
			currentPosition.displayLevel = MAIN_MENU_POSITION;
			currentPosition.lineNumber   = 1;
		}
		else
		{
			currentPosition.lineNumber   = INLET_LINENUM;
		}
//		displayMemoryNeedsUpdate = true;
		clearDisplay();
	}
	else if (fourButtonsPressed)
	{
		fourButtonsPressed = false;
		currentPosition.displayLevel = CHECK_ALL_PIXELS;
//		displayMemoryNeedsUpdate = true;
	}
	else if (pressedBack && !buttonHold)
	{
		pressedBack = false;

		if (currentPosition.lineNumber != INLET_LINENUM)
		{
			currentPosition.lineNumber   = INLET_LINENUM;
			displayMemoryNeedsUpdate = true;
		}
	}
	else if (releasedUp)
	{
		releasedUp = false;
		clearDisplay();
		if (currentPosition.lineNumber == INLET_LINENUM)
		{
			currentPosition.lineNumber = COIL_LINENUM;
		}
		else if (currentPosition.lineNumber == COIL_LINENUM)
		{
			if (probe2IsPresent)
			{
				currentPosition.lineNumber = OUTLET_LINENUM;
			}
			else
			{
				currentPosition.lineNumber = INLET_LINENUM;
			}
		}
		else if (currentPosition.lineNumber == OUTLET_LINENUM)
		{
			currentPosition.lineNumber = INLET_LINENUM;
		}

//		displayMemoryNeedsUpdate = true;
	}
	else if (releasedDown)
	{
		releasedDown = false;
		clearDisplay();
		if (currentPosition.lineNumber == COIL_LINENUM)
		{
			currentPosition.lineNumber = INLET_LINENUM;
		}
		else if (currentPosition.lineNumber == INLET_LINENUM)
		{
			if (probe2IsPresent)
			{
				currentPosition.lineNumber = OUTLET_LINENUM;
			}
			else
			{
				currentPosition.lineNumber = COIL_LINENUM;
			}
		}
		else if (currentPosition.lineNumber == OUTLET_LINENUM)
		{
			currentPosition.lineNumber = COIL_LINENUM;
		}
//		displayMemoryNeedsUpdate = true;
	}
	else
	{
		/* Working Status 1 */
		showWorkingStatus1();

		/* Working Status 2 */
		showWorkingStatus2();

		int workingStatus_2 = modbus_ro_reg_rcv[WORKING_STATUS_2].ivalue;

		/* Heater */
		if (workingStatus_2 & 0x1000)
		{
			showIcon(resisterIcon, 14, 2, 6, 34);
		}

		/* Condensor */
		if (workingStatus_2 & 0x2000)
		{
			showIcon(condensorIcon, 14, 2, 6, 53);
		}

		/* Evaporator */
		if (workingStatus_2 & 0x4000)
		{
			showIcon(evapIcon, 14, 2, 6, 91);
		}

		/* Compressor */
		if (workingStatus_2 & 0x8000)
		{
			showIcon(compIcon, 14, 2, 6, 110);
		}

		/* Power */
		showIcon(snowFlakeIcon, 14, 2, 4, 0);

		/* Probe#1 - #3 */
		switch (currentPosition.lineNumber)
		{
			case INLET_LINENUM:
				showTempReading(modbus_ro_reg_rcv[PROBE_1].ivalue, 1, 110);
				break;

			case OUTLET_LINENUM:
				clearDisplay();
				displayString("Outlet Temp", arial_bold14, 0, 30);
				showTempReading(modbus_ro_reg_rcv[PROBE_2].ivalue, 2, 110);
				break;

			case COIL_LINENUM:
				clearDisplay();
				displayString("Cond Coil Temp", arial_bold14, 0, 20);
				showTempReading(modbus_ro_reg_rcv[PROBE_3].ivalue, 2, 110);
				break;

			default: break;
		}

		updateScreen = true;
	}
}

void showWorkingStatus1(void)
{
	int workingStatus_1 = modbus_ro_reg_rcv[WORKING_STATUS_1].ivalue;

	//	0 - Phase Missing
	if (workingStatus_1 & 0x0001)
	{
		alarmOutput[PHASE_MISSING] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[PHASE_MISSING] = 0;
	}

	// 	1 - Evap MI Thermal Overload
	if (workingStatus_1 & 0x0002)
	{
		alarmOutput[EVAP_MI_THERMAL_OVERLOAD] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[EVAP_MI_THERMAL_OVERLOAD] = 0;
	}

	//	2 - Imbalance Voltage
	//	3 - Over Voltage
	if (workingStatus_1 & 0x0008)
	{
		alarmOutput[OVER_VOLTAGE] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[OVER_VOLTAGE] = 0;
	}

	//	4 - Under Voltage
	if (workingStatus_1 & 0x0010)
	{
		alarmOutput[UNDER_VOLTAGE] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[UNDER_VOLTAGE] = 0;
	}

	//	5 - Door/Smoke Alarm
	if (workingStatus_1 & 0x0020)
	{
		alarmOutput[DOOR_SMOKE] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[DOOR_SMOKE] = 0;
	}

	//	6 - Coil Temp Sensor Fault
	if (workingStatus_1 & 0x0040)
	{
		alarmOutput[COIL_TEMP_SENSOR_FAULT] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[COIL_TEMP_SENSOR_FAULT] = 0;
	}

	//	7 - Low Pressure Alarm
//			if (workingStatus_1 & 0x0080)
//			{
//				alarmOutput[LOW_PRESSURE] = 1;
//				TI1_alarmTimer_Flag = true;
//				displayMemoryNeedsUpdate = true;
//			}
//			else
//			{
//				alarmOutput[LOW_PRESSURE] = 0;
//			}

	//	8 - Compressor Thermal Overload
	if (workingStatus_1 & 0x0100)
	{
		showIcon(bellIcon, 14, 2, 6, 15);
		alarmOutput[COMPRESSOR_THERMAL_OVERLOAD] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[COMPRESSOR_THERMAL_OVERLOAD] = 0;
	}

	//	9 - Bad Board
	if (workingStatus_1 & 0x0200)
	{
		showIcon(bellIcon, 14, 2, 6, 15);
		alarmOutput[BAD_BOARD] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[BAD_BOARD] = 0;
	}

	//	10 - Reverse Relay On
	//	11 - High Pressure Alarm
	if (workingStatus_1 & 0x0800)
	{
		showIcon(bellIcon, 14, 2, 6, 15);
		alarmOutput[HIGH_PRESSURE] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[HIGH_PRESSURE] = 0;
	}

	//	12 - Condensor MI Thermal Overload
	if (workingStatus_1 & 0x1000)
	{
		showIcon(bellIcon, 14, 2, 6, 15);
		alarmOutput[CONDENSOR_MI_THERMAL_OVERLOAD] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[CONDENSOR_MI_THERMAL_OVERLOAD] = 0;
	}

	//	13 - Forward Relay On
	//	14 - Inlet Temp Sensor Fault
	if (workingStatus_1 & 0x4000)
	{
		showIcon(bellIcon, 14, 2, 6, 15);
		alarmOutput[INLET_TEMP_SENSOR_FAULT] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[INLET_TEMP_SENSOR_FAULT] = 0;
	}

	//	15 - Outlet Temp Sensor Fault
	if (workingStatus_1 & 0x8000)
	{
		alarmOutput[OUTLET_TEMP_SENSOR_FAULT] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[OUTLET_TEMP_SENSOR_FAULT] = 0;
	}
}

void showWorkingStatus2(void)
{
	int workingStatus_2 = modbus_ro_reg_rcv[WORKING_STATUS_2].ivalue;

	//	0 - Frost Alarm
	if (workingStatus_2 & 0x0001)
	{
		alarmOutput[FROST] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[FROST] = 0;
	}

	//	1 - Degraded mode
	//	2 - Probe 2 Present
	//	3 - Diagnostics Mode

	//	4 - Low Temp Alarm
	if (workingStatus_2 & 0x0010)
	{
		alarmOutput[LOW_TEMP] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[LOW_TEMP] = 0;
	}

	//	5 - High Temp Alarm
	if (workingStatus_2 & 0x0020)
	{
		alarmOutput[HIGH_TEMP] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[HIGH_TEMP] = 0;
	}

	//	6 - Disable Switch Alarm
	if (workingStatus_2 & 0x0040)
	{
		alarmOutput[DISABLE_SWITCH_ALARM] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[DISABLE_SWITCH_ALARM] = 0;
	}

	//	7 - Over Current
	if (workingStatus_2 & 0x0080)
	{
		alarmOutput[OVER_CURRENT] = 1;
		showIcon(bellIcon, 14, 2, 6, 15);
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[OVER_CURRENT] = 0;
	}

	//	8 - Cooling On
	if ((workingStatus_2 & 0x0100) && modbus_ro_reg_rcv[COMP_DELAY_TIMER].ivalue > 0)
	{
		alarmOutput[COMPRESSOR_COUNT_DOWN] = 1;
		alarmOutput[COMPRESSOR_COUNT_DOWN_TIMER] = 1;
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		alarmOutput[COMPRESSOR_COUNT_DOWN] = 0;
		alarmOutput[COMPRESSOR_COUNT_DOWN_TIMER] = 0;
	}

	//	9 - Not Used
	//	10 - Not Used
	//	11 - Not Used
	//	12 - Heater On
	//	13 - Condensor MI On
	//	14 - Evap MI On
	//	15 - Compressor On
}

void showDegree(unsigned char page, unsigned char column)
{
	if (modbus_rw_coil_rcv[UNIT_OF_MEASURE/8] & UNIT_OF_MEASURE_F)
	{
		showIcon(degreeF, 8, 2, page, column);
	}
	else
	{
		showIcon(degreeC, 8, 2, page, column);
	}
}

void showTempReading(int tempReading, unsigned char page, unsigned char column)
{
	if ((tempReading >= 1000) || (tempReading <= -1000))
	{
		showIntegerRightAligned(digitCalibriLight5x30, tempReading/10, 5, 30, page, column);
	}
	else
	{
		showIntegerRightAligned(digitCalibriLight5x30, tempReading, 5, 30, page, column);
		showIcon(decimal_point, DECIMAL_POINT_WIDTH, 1, page+3, column-30);
	}
	/* degree F/C */
	showDegree(page,115);
}

void showTimer(const char font[], unsigned char minute, unsigned char second, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column)
{
	if (minute >= 100)
	{
		minute = 99;
	}
	else if (minute <= -1)
	{
		minute = 0;
	}

	if (second >= 60)
	{
		second = 59;
	}
	else if (second <= -1)
	{
		second = 0;
	}

	// Minute
	showDigit(font, minute/10, heightInPages, widthInRows, page, column);
	showDigit(font, minute%10, heightInPages, widthInRows, page, column+widthInRows);

	// :
	showIcon(decimal_point, DECIMAL_POINT_WIDTH, 1, page, column + widthInRows*2+2);
	showIcon(decimal_point, DECIMAL_POINT_WIDTH, 1, page+3, column + widthInRows*2+2);

	// second
	showDigit(font, second/10, heightInPages, widthInRows, page, column + widthInRows*2+6);
	showDigit(font, second%10, heightInPages, widthInRows, page, column + widthInRows*3+6);
}

void showAlarm(int alarmPosition)
{
	if (pressedOK)
	{
		pressedBack = false;
		// Turn off alarm timer and clear its counter
		TI1_alarmTimer_Flag = false;
		TI1_alarmTimer = 0;
		currentPosition.displayLevel = MAIN_MENU_POSITION;
		currentPosition.lineNumber   = 1; // Always set line number to 1 when is about to change to different screen
		displayMemoryNeedsUpdate = true;
	}
	else if (pressedUp)
	{
		pressedUp = false;
		// Turn off alarm timer and clear its counter
		TI1_alarmTimer_Flag = false;
		TI1_alarmTimer = 0;
		currentPosition.displayLevel = MAIN_SCREEN_POSITION;
		currentPosition.lineNumber   = OUTLET_LINENUM;
		clearDisplay();
		displayMemoryNeedsUpdate = true;
	}
	else if (pressedDown)
	{
		pressedDown = false;
		// Turn off alarm timer and clear its counter
		TI1_alarmTimer_Flag = false;
		TI1_alarmTimer = 0;
		currentPosition.displayLevel = MAIN_SCREEN_POSITION;
		currentPosition.lineNumber   = COIL_LINENUM;
		clearDisplay();
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		clearDisplay();

		switch (alarmPosition)
		{
			case HIGH_TEMP_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("High Temp Alarm", arial_bold14, 3, 23);
				break;

			case LOW_TEMP_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Low Temp Alarm", arial_bold14, 3, 23);
				break;

			case DOOR_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 15);
				displayString("Door/Smoke", arial_bold14, 3, 35);
				break;

			case PHASE_MISSING_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 15);
				displayString("Phase Missing", arial_bold14, 3, 35);
				break;

			case EVAP_MI_THERMAL_OVERLOAD_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 3);
				displayString("Evaporator Fan", arial_bold14, 2, 23);
				displayString("Thermal Overload", arial_bold14, 4, 23);
				break;

			case CONDENSOR_MI_THERMAL_OVERLOAD_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 3);
				displayString("Condenser Fan", arial_bold14, 2, 23);
				displayString("Thermal Overload", arial_bold14, 4, 23);
				break;

			case COMPRESSOR_THERMAL_OVERLOAD_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 3);
				displayString("Compressor", arial_bold14, 2, 23);
				displayString("Thermal Overload", arial_bold14, 4, 23);
				break;

			case OVER_VOLTAGE_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 15);
				displayString("Over Voltage", arial_bold14, 3, 35);
				break;

			case UNDER_VOLTAGE_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 15);
				displayString("Under Voltage", arial_bold14, 3, 35);
				break;

			case BAD_BOARD_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Controller Board", arial_bold14, 2, 25);
				displayString("Malfunction", arial_bold14, 4, 26);
				break;

			case HIGH_PRESSURE_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Unit Malfunction:", arial_bold14, 2, 25);
				displayString("High Pressure", arial_bold14, 4, 25);
				break;

			case LOW_PRESSURE_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 15);
				displayString("Low Pressure", arial_bold14, 3, 35);
				break;

			case FROST_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Frost Detected", arial_bold14, 0, 25);
				displayString("Compressor and", arial_bold14, 2, 25);
				displayString("Condenser Fan", arial_bold14, 4, 25);
				displayString("Disabled", arial_bold14, 6, 25);
				break;

			case DISABLE_SWITCH_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 10);
				displayString("Disable Switch", arial_bold14, 2, 30);
				displayString("Activated", arial_bold14, 4, 30);
				break;

			case COIL_TEMP_SENSOR_FAULT_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Condenser Coil", arial_bold14, 1, 25);
				displayString("Temp Sensor", arial_bold14, 3, 25);
				displayString("Malfunction", arial_bold14, 5, 26);
				break;

			case INLET_TEMP_SENSOR_FAULT_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Enclosure Inlet", arial_bold14, 1, 25);
				displayString("Air Temp Sensor", arial_bold14, 3, 25);
				displayString("Malfunction", arial_bold14, 5, 26);
				break;

			case OUTLET_TEMP_SENSOR_FAULT_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 5);
				displayString("Enclosure Outlet", arial_bold14, 1, 25);
				displayString("Air Temp Sensor", arial_bold14, 3, 25);
				displayString("Malfunction", arial_bold14, 5, 26);
				break;

			case OVER_CURRENT_ALARM_POSITION:
				showIcon(attentionIcon, 16, 2, 3, 10);
				displayString("Over Current", arial_bold14, 3, 30);
				break;

			case COMPRESSOR_RESTART_DELAY_COUNT_DOWN_POSITION:
				displayString("Restart Delay Active", arial_bold14, 3, 5);
				break;

			case COMPRESSOR_RESTART_DELAY_TIMER_POSITION:
				showTimer(digitCalibri5x30, modbus_ro_reg_rcv[COMP_DELAY_TIMER].ivalue/60, modbus_ro_reg_rcv[COMP_DELAY_TIMER].ivalue%60, 5, 30, 1, 0);
				break;

			default: break;
		}
		// Turn on alarm timer
		TI1_alarmTimer_Flag = true;
		displayMemoryNeedsUpdate = true;
		/* Set the updateScreen flag */
		updateScreen = true;
	}
}
