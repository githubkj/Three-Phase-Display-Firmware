#ifndef __USER_MENU_H
#define __USER_MENU_H

void coolingSPMenu(void);
void coolingDifMenu(void);
void heatingSPMenu(void);
void heatingDifMenu(void);
void highTempAlarmSPMenu(void);
void lowTempAlarmSPMenu(void);
void tempScaleMenu(void);
void hysteresisMenu(void);
void languageMenu(void);
void passwordMenu(void);

#endif /* __USER_MENU_H */
