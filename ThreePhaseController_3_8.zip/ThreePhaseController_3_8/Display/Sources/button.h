#ifndef __BUTTON_H
#define __BUTTON_H

#include "stdbool.h"

/* Global Variables */

	extern _Bool pressedBack;
	extern _Bool pressedOK;
	extern _Bool pressedUp;
	extern _Bool pressedDown;
	extern _Bool fourButtonsPressed;

	extern _Bool releasedUp;
	extern _Bool releasedDown;

	extern _Bool heldUp;
	extern _Bool heldDown;
/* Function Prototype */

	void scanButton(void);

#endif
