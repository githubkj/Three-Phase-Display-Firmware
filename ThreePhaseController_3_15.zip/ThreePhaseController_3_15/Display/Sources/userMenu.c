#include "userMenu.h"
#include "screen.h"
#include "digit.h"
#include "text.h"
#include "OLED.h"
#include "button.h"
#include "icon.h"
#include "stdbool.h"
#include "displayMemory.h"
#include "display_UART.h"
#include "PE_Types.h"
#include "Events.h"

uint16_union modbus_rw_reg_rcv[RW_REG_LEN];					// read/write registers controller copy
byte modbus_rw_coil_rcv[RW_COIL_LEN/8+1];					// read/write coils controller copy

void coolingSPMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = COOLING_SP_LINENUM;
		clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COOLING_SP, false, userInput, COOLING_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
		clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		if (userInput < modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
		{
			userInput += 10;
			if (userInput > modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
			{
				userInput = modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue;
			}
		}
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		if (userInput > modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
		{
			userInput -= 10;
    		if (userInput < modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
    		{
				userInput = modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue;
    		}
		}
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
			if (userInput < modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
			{
				userInput += 10;
				if (userInput > modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
				{
					userInput = modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue;
				}
			}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
			if (userInput > modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
			{
				userInput -= 10;
	    		if (userInput < modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
	    		{
					userInput = modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue;
	    		}
			}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Cooling set point", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[COOLING_SP].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		displayHighlightedString("   Cooling Set Point   ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void coolingDifMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = COOLING_DIF_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COOLING_DIF_1, false, userInput, COOLING_DIF_1_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
    	userInput += 10;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    	userInput -= 10;
    	if (userInput < 0)
    	{
    		userInput = 0;
    	}
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
			userInput += 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
	    	userInput -= 10;
	    	if (userInput < 0)
	    	{
	    		userInput = 0;
	    	}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Cooling differential", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[COOLING_DIF_1].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		clearDisplay();
    		displayHighlightedString("  Cooling Differential ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void heatingSPMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HEATING_SP_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HEATING_SP, false, userInput, HEATING_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		if (userInput < modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
		{
			userInput += 10;
			if (userInput > modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
			{
				userInput = modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue;
			}
		}
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		if (userInput > modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
		{
			userInput -= 10;
    		if (userInput < modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
    		{
				userInput = modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue;
    		}
		}
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
			if (userInput < modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
			{
				userInput += 10;
				if (userInput > modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
				{
					userInput = modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue;
				}
			}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
			if (userInput > modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
			{
				userInput -= 10;
	    		if (userInput < modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
	    		{
					userInput = modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue;
	    		}
			}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Heating set point", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[HEATING_SP].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		clearDisplay();
    		displayHighlightedString("   Heating Set Point   ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void heatingDifMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HEATING_DIF_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HEATING_DIF, false, userInput, HEATING_DIF_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
    	userInput += 10;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    	userInput -= 10;
    	if (userInput < 0)
    	{
    		userInput = 0;
    	}
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
	    	userInput += 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
	    	userInput -= 10;
	    	if (userInput < 0)
	    	{
	    		userInput = 0;
	    	}
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Heating differential", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[HEATING_DIF].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		clearDisplay();
    		// Title
    		displayHighlightedString("  Heating Differential ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void highTempAlarmSPMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HIGH_TEMP_ALARM_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HIGH_TEMP_ALARM_SP, false, userInput, HIGH_TEMP_ALARM_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	clearDisplay();
    	TI1_validationScreenTimer_Flag = true;
    }
    else if (releasedUp)
    {
    	releasedUp = false;
    	userInput += 10;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		userInput -= 10;
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
	    	userInput += 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
	    	userInput -= 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("High temp alarm", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[HIGH_TEMP_ALARM_SP].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		clearDisplay();
    		// Title
    		displayHighlightedString("   High Temp Alarm   ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void lowTempAlarmSPMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = LOW_TEMP_ALARM_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + LOW_TEMP_ALARM_SP, false, userInput, LOW_TEMP_ALARM_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		userInput += 10;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    	userInput -= 10;
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
	    	userInput += 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
	    	userInput -= 10;
			showTempReading(userInput, 3, 110);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Low temp alarm", arial_bold14, 2, 10);
        	displayString("is set to", arial_bold14, 4, 10);
    		showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[LOW_TEMP_ALARM_SP].ivalue/10, 2, 7, 4, 75);
    		showDegree(4, 100);
    	}
    	else
    	{
    		clearDisplay();
    		// Title
    		displayHighlightedString("   Low Temp Alarm    ", arial_bold14, 0, 0);
			showTempReading(userInput, 3, 110);
    	}
        updateScreen = true;
    }
}

void tempScaleMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = TEMP_SCALE_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // degree F
				uart_write_return = display_uart_update(COIL, RW_COIL_START + UNIT_OF_MEASURE, true, 0, 0, UNIT_OF_MEASURE_F);
				break;

			case 2: // degree C
				uart_write_return = display_uart_update(COIL, RW_COIL_START + UNIT_OF_MEASURE, false, 0, 0, UNIT_OF_MEASURE_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
    else
    {
    	if (parameterIsSet)
    	{
    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE/8] & UNIT_OF_MEASURE_F)
    		{
	    		displayString("Set to degree F ", arial_bold14, 3, 15);
    		}
    		else
    		{
	    		displayString("Set to degree C ", arial_bold14, 3, 15);
    		}
    	}
    	else
    	{
    		displayHighlightedString("  Temperature Scale  ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * Fahrenheit", arial14, 2, 0);
					displayString("   Celsius", arial14, 4, 0);
					break;
				case 2:
					displayString("   Fahrenheit", arial14, 2, 0);
					displayString(" * Celsius", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}

void hysteresisMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HYSTERESIS_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // positive
				uart_write_return = display_uart_update(COIL, RW_COIL_START + COOL_HYSTERESIS, false, 0, 0, COOL_HYSTERESIS_F);
				break;

			case 2: // negative
				uart_write_return = display_uart_update(COIL, RW_COIL_START + COOL_HYSTERESIS, true, 0, 0, COOL_HYSTERESIS_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Positive
    	    		displayString("Hysteresis: Positive", arial_bold14, 3, 5);
    				break;

    			case 2: // Negative
    	    		displayString("Hysteresis: Negative", arial_bold14, 3, 5);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("      Hysteresis       ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * Positive", arial14, 2, 0);
					displayString("   Negative", arial14, 4, 0);
					break;
				case 2:
					displayString("   Positive", arial14, 2, 0);
					displayString(" * Negative", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}

void languageMenu(void)
{
	char *languageMenuItems[] = {
			"       Language        ",
        	"   English    ",
            "   Chinese    ",
            "   French     ",
			"   German     ",
            "   Italian    ",
            "   Polish     ",
			"   Spanish    "
	};

    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber   = LANGUAGE_LINENUM;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    }
    else if (releasedUp)
    {
    	releasedUp = false;
    	if (currentPosition.lineNumber > 1)
    	{
            currentPosition.lineNumber -= 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 1;
        }
    	clearDisplay();
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    	if (currentPosition.lineNumber < 7)
    	{
            currentPosition.lineNumber += 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 7;
        }
    	clearDisplay();
    }
    else
    {
		displayHighlightedString(languageMenuItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
            case 1: case 2: case 3:
        		displayString(languageMenuItems[1], arial14, 2, 0);
        		displayString(languageMenuItems[2], arial14, 4, 0);
        		displayString(languageMenuItems[3], arial14, 6, 0);
                break;

            case 4: case 5: case 6:
        		displayString(languageMenuItems[4], arial14, 2, 0);
        		displayString(languageMenuItems[5], arial14, 4, 0);
        		displayString(languageMenuItems[6], arial14, 6, 0);
                break;

            case 7:
        		displayString(languageMenuItems[7], arial14, 2, 0);
                break;

            default: break;
        }

		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
    }
}

void passwordMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = PASSWORD_LINENUM;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
		switch (currentPosition.lineNumber)
		{
		case 1:
			uart_write_return = display_uart_update(COIL, RW_COIL_START + PASSWORD_ENABLED, false, 0, 0, PASSWORD_ENABLED_F);
			break;

		case 2:
			uart_write_return = display_uart_update(COIL, RW_COIL_START + PASSWORD_ENABLED, true, 0, 0, PASSWORD_ENABLED_F);
			break;

		default: break;
		}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
	else
	{
    	if (parameterIsSet)
    	{
    		if (currentPosition.lineNumber == 2)
			{
	    		displayString("  Password for User", arial_bold14, 2, 0);
	    		displayString("  Interface is ON", arial_bold14, 4, 0);
			}
			else if (currentPosition.lineNumber == 1)
			{
				displayString("  Password for User", arial_bold14, 2, 0);
				displayString("  Interface is OFF", arial_bold14, 4, 0);
			}
    	}
    	else
    	{
    		displayHighlightedString("        Password        ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * OFF", arial14, 2, 0);
					displayString("   ON", arial14, 4, 0);
					break;
				case 2:
					displayString("   OFF", arial14, 2, 0);
					displayString(" * ON", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}
