#ifndef __DISPLAY_MEMORY_H
#define __DISPLAY_MEMORY_H

extern int userInput;
extern _Bool parameterIsSet;

void updateDisplayMemory(void);

#endif /* __DISPLAY_MEMORY_H */
