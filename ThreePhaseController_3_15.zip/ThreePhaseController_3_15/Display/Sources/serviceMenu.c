#include "serviceMenu.h"
#include "screen.h"
#include "digit.h"
#include "text.h"
#include "OLED.h"
#include "button.h"
#include "icon.h"
#include "stdbool.h"
#include "displayMemory.h"
#include "display_UART.h"
#include "PE_Types.h"
#include "Events.h"

uint16_union modbus_ro_reg_rcv[RO_REG_LEN];					// read only registers controller copy
uint16_union modbus_ero_reg_rcv[ERO_REG_LEN+1];			// extended read only registers

void doorSmokeAlarmMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 1;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DOOR_SWITCH, false, 0, 0, DOOR_SWITCH_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DOOR_SWITCH, true, 0, 0, DOOR_SWITCH_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("  Door/Smoke Alarm", arial_bold14, 2, 0);
    	    		displayString("  is Normally Open", arial_bold14, 4, 0);
    				break;

    			case 2: // Normally Close
    	    		displayString("  Door/Smoke Alarm", arial_bold14, 2, 0);
    	    		displayString("  is Normally Close", arial_bold14, 4, 0);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("   Door/Smoke Alarm   ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("   Normally Close", arial14, 4, 0);
    				break;

    			case 2:
    				displayString("   Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;

    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void disableSwitchAlarmMenu(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 2;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DISABLE_SWITCH, false, 0, 0, DISABLE_SWITCH_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DISABLE_SWITCH, true, 0, 0, DISABLE_SWITCH_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("  Disable Switch", arial_bold14, 2, 5);
    	    		displayString("  is Normally Open", arial_bold14, 4, 5);
    				break;

    			case 2: // Normally Close
    	    		displayString("  Disable Switch", arial_bold14, 2, 5);
    	    		displayString("  is Normally Close", arial_bold14, 4, 5);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("    Disable Switch    ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("   Normally Close", arial14, 4, 0);
    				break;
    			case 2:
    				displayString("   Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;
    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void alarmRelayOutput(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 3;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + ALARM_OUTPUT, false, 0, 0, ALARM_OUTPUT_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + ALARM_OUTPUT, true, 0, 0, ALARM_OUTPUT_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		currentPosition.lineNumber = 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		currentPosition.lineNumber = 2;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("Alarm Relay Output", arial_bold14, 2, 10);
    	    		displayString("is Normally Open", arial_bold14, 4, 10);
    				break;

    			case 2: // Normally Close
    	    		displayString("Alarm Relay Output", arial_bold14, 2, 10);
    	    		displayString("is Normally Close", arial_bold14, 4, 10);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("  Alarm Relay Output  ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("   Normally Close", arial14, 4, 0);
    				break;
    			case 2:
    				displayString("   Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;
    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void compressorRestartDelay(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber = 4;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COMP_MIN_STOP_TIME, false, userInput, COMP_MIN_STOP_TIME_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		userInput += 1;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		userInput -= 1;
    }
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
	    	if (userInput < 5999) // 5999 second is 99 minutes and 59 second
	    	{
				userInput += 1;
	    	}
    		showTimer(digitCalibriLight4x28, userInput/60, userInput%60, 4, 28, 3, 5);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
	    	if (userInput > 0)
	    	{
				userInput -= 1;
	    	}
    		showTimer(digitCalibriLight4x28, userInput/60, userInput%60, 4, 28, 3, 5);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = BUTTON_HELD_REFRESH_TIME;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Comp Restart Delay", arial_bold14, 2, 5);
        	showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[COMP_MIN_STOP_TIME].ivalue/60, 2, 7, 4, 5);
        	displayString("min", arial_bold14, 4, 25);
        	showIntegerLeftAligned(digitCourier2x7, modbus_rw_reg_rcv[COMP_MIN_STOP_TIME].ivalue%60, 2, 7, 4, 60);
        	displayString("sec", arial_bold14, 4, 90);
    	}
    	else
    	{
    		displayHighlightedString(" Comp Restart Delay ", arial_bold14, 0, 0);
    		showTimer(digitCalibriLight4x28, userInput/60, userInput%60, 4, 28, 3, 5);
    	}
        updateScreen = true;
    }
}

void compressorCurrent(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 5;
        clearDisplay();
    }
    else if (releasedOK)
    {
    	releasedOK = false;
    }
    else if (releasedUp)
    {
    	releasedUp = false;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    }
    else
    {
    	displayHighlightedString(" Compressor Current ", arial_bold14, 0, 0);
		displayString("Phase 1:", arial_bold14, 2, 2);
		displayString("Phase 2:", arial_bold14, 4, 2);
		displayString("Phase 3:", arial_bold14, 6, 2);

		if (modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10 <= 99)
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10, 2, 7, 2, 70);
			displayString("mA", arial_bold14, 2, 100);
		}
		else
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10000, 2, 7, 2, 70);
			displayString(".", courier7x14, 2, 78); // decimal point
			showIntegerLeftAligned(digitCourier2x7, (modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10-(modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10/1000)*1000)/100, 2, 7, 2, 85);
			displayString("A", arial_bold14, 2, 100);
		}

		if (modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10 <= 99)
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10, 2, 7, 4, 70);
			displayString("mA", arial_bold14, 4, 100);
		}
		else
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10000, 2, 7, 4, 70);
			displayString(".", courier7x14, 4, 78); // decimal point
			showIntegerLeftAligned(digitCourier2x7, (modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10-(modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10/1000)*1000)/100, 2, 7, 4, 85);
			displayString("A", arial_bold14, 4, 100);
		}

		if (modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10 <= 99)
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10, 2, 7, 6, 70);
			displayString("mA", arial_bold14, 6, 100);
		}
		else
		{
			showIntegerLeftAligned(digitCourier2x7, modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10000, 2, 7, 6, 70);
			displayString(".", courier7x14, 6, 78); // decimal point
			showIntegerLeftAligned(digitCourier2x7, (modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10-(modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10/1000)*1000)/100, 2, 7, 6, 85);
			displayString("A", arial_bold14, 6, 100);
		}

        updateScreen = true;
    }
}

void displaySystemSettings(void)
{
	char *systemSettingItems[] = {
			" Display SYS Settings ",
	    	"   Current limit setting ",
	        "   MALF Activate         ",
	        "   MALF Deactivate       ",
	    	"   HPC Fan ON            ",
	    	"   HPC Fan OFF           "
	};

    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 6;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        switch (currentPosition.lineNumber)
        {
            case 1:
                currentPosition.displayLevel = CURRENT_LIMIT_SETTINGS_POSITION;
                break;

            case 2:
                currentPosition.displayLevel = MALF_ACTIVATE_POSITION;
                break;

            case 3:
                currentPosition.displayLevel = MALF_DEACTIVATE_POSITION;
                break;

            case 4:
                currentPosition.displayLevel = HPC_FAN_ON_POSITION;
                break;

            case 5:
                currentPosition.displayLevel = HPC_FAN_OFF_POSITION;
                break;

            default: break;
        }
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
    	if (currentPosition.lineNumber == 1)
    	{
            currentPosition.lineNumber = 5;
    	}
    	else
    	{
            currentPosition.lineNumber -= 1;
        }
    }
    else if (releasedDown)
    {
    	releasedDown = false;
    	if (currentPosition.lineNumber == 5)
    	{
            currentPosition.lineNumber = 1;
    	}
    	else
    	{
            currentPosition.lineNumber += 1;
        }
    }
	else
	{
		displayHighlightedString(systemSettingItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
            case 1: case 2: case 3:
        		displayString(systemSettingItems[1], arial14, 2, 0);
        		displayString(systemSettingItems[2], arial14, 4, 0);
        		displayString(systemSettingItems[3], arial14, 6, 0);
                break;

            case 4: case 5:
        		displayString(systemSettingItems[4], arial14, 2, 0);
        		displayString(systemSettingItems[5], arial14, 4, 0);
        		displayString("                         ", arial14, 6, 0);
                break;

            default: break;
        }
		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
	}
}

void currentLimitSettings(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 1;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 1;
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
	}
    else if (releasedDown)
    {
    	releasedDown = false;
	}
	else
	{
		displayHighlightedString(" Current limit setting ", arial_bold14, 0, 0);
    	int currentLimit = modbus_ero_reg_rcv[4].ivalue/10;

		if (currentLimit <= 99)
		{
			showIntegerLeftAligned(digitCourier2x7, currentLimit, 2, 7, 3, 30);
			displayString("mA", arial_bold14, 3, 60);
		}
		else
		{
			showIntegerLeftAligned(digitCourier2x7, currentLimit/1000, 2, 7, 3, 25);
			displayString(".", courier7x14, 3, 40); // decimal point
			showIntegerLeftAligned(digitCourier2x7, (currentLimit-(currentLimit/1000)*1000)/100, 2, 7, 3, 60);
			displayString("A", arial_bold14, 3, 80);
		}

        updateScreen = true;
	}
}

void malfActivate(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 2;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 2;
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
	}
    else if (releasedDown)
    {
    	releasedDown = false;
	}
	else
	{
		displayHighlightedString("    MALF Activate     ", arial_bold14, 0, 0);
		showTempReading(modbus_ero_reg_rcv[MALF_ACTIVATE].ivalue, 3, 110);
        updateScreen = true;
	}
}

void malfDeactivate(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 3;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 3;
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
	}
    else if (releasedDown)
    {
    	releasedDown = false;
	}
	else
	{
		displayHighlightedString("   MALF Deactivate   ", arial_bold14, 0, 0);
		showTempReading(modbus_ero_reg_rcv[MALF_DEACTIVATE].ivalue, 3, 110);
        updateScreen = true;
	}
}

void hpcFanOn(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 4;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 4;
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
	}
    else if (releasedDown)
    {
    	releasedDown = false;
	}
	else
	{
		displayHighlightedString("      HPC Fan ON      ", arial_bold14, 0, 0);
		showTempReading(modbus_ero_reg_rcv[HPC_DEACTIVATE].ivalue, 3, 110);
        updateScreen = true;
	}
}

void hpcFanOff(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 5;
        clearDisplay();
	}
    else if (releasedOK)
    {
    	releasedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 5;
        clearDisplay();
	}
    else if (releasedUp)
    {
    	releasedUp = false;
	}
    else if (releasedDown)
    {
    	releasedDown = false;
	}
	else
	{
		displayHighlightedString("      HPC Fan OFF     ", arial_bold14, 0, 0);
		showTempReading(modbus_ero_reg_rcv[HPC_ACTIVATE].ivalue, 3, 110);
        updateScreen = true;
	}
}
