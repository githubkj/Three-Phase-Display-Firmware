#include "displayMemory.h"
#include "screen.h"
#include "menu.h"
#include "mainMenu.h"
#include "userMenu.h"
#include "serviceMenu.h"
#include "OLED.h"
#include "stdbool.h"
#include "Events.h"
#include "icon.h"

void updateDisplayMemory(void)
{
	switch (currentPosition.displayLevel)
	{
		/* Display Pentair Logo for 1 second at Start-up */
		case PENTAIR_ICON_POSITION:
			if (!TI1_pentairIconTimer_Flag)
			{
				clearDisplay();
				showPentairLogo();
				updateScreen = true;
				TI1_pentairIconTimer_Flag = true;
			}
			break;

		/* Display All Icons for 1 second at Start-up */
		case ICON_ALL_ON_POSITION:
			if (!TI1_iconAllOnTimer_Flag)
			{
				clearDisplay();
				displayAllOn();
				updateScreen = true;
				TI1_iconAllOnTimer_Flag = true;
			}
			break;

		// Main Screen
		case MAIN_SCREEN_POSITION:
			clearDisplay();
			mainScreen();
			break;

//		case CHECK_ALL_PIXELS:
//			turnOnAllPixels();
//			break;

		// Main Menu
		case MAIN_MENU_POSITION:
			clearDisplay();
			mainMenu();
			break;

			case USER_PASSWORD_POSITION: case SYSTEM_PASSWORD_POSITION:
				enterPassword();
				break;

//			case ABOUT_POSITION:
//				aboutMenu();
//				break;
//
//			case LANGUAGE_MENU_POSITION:
//				languageMenu();
//				break;
//
//			case USER_INTERFACE_POSITION:
//				userInterfaceMenu();
//				break;
//
//			case SYSTEM_INTERFACE_POSITION:
//				clearDisplay();
//				systemInterfaceMenu();
//				break;
//
//			// User Interface
//			case COOLING_SET_POINT_POSITION:
//				coolingSPMenu();
//				break;
//
//			case COOLING_DIF_POSITION:
//				coolingDifMenu();
//				break;
//
//			case HEATING_SET_POINT_POSITION:
//				heatingSPMenu();
//				break;
//
//			case HEATING_DIF_POSITION:
//				heatingDifMenu();
//				break;
//
//			case HIGH_TEMP_ALARM_SP_POSITION:
//				highTempAlarmSPMenu();
//				break;
//
//			case LOW_TEMP_ALARM_SP_POSITION:
//				lowTempAlarmSPMenu();
//				break;
//
//			case TEMP_SCALE_POSITION:
//				tempScaleMenu();
//				break;
//
//			case HYSTERESIS_POSITION:
//				hysteresisMenu();
//				break;
//
//			case PASSWORD_POSITION:
//				passwordMenu();
//				break;
//
//			// System Interface
//			case DOOR_SMOKE_ALARM_POSITION:
//				doorSmokeAlarmMenu();
//				break;
//
//			case DISABLE_SWITCH_POSITION:
//				disableSwitchAlarmMenu();
//				break;
//
//			case ALARM_RELAY_OUTPUT_POSITION:
//				alarmRelayOutput();
//				break;
//
//			case COMPRESSOR_RESTART_DELAY_POSITION:
//				compressorRestartDelay();
//				break;
//
//			case COMPRESSOR_CURRENT_POSITION:
//				compressorCurrent();
//				break;
//
//			// Display System Settings
//			case DISPLAY_SYS_SETTINGS_MENU_POSITION:
//				displaySystemSettings();
//				break;
//
//			case CURRENT_LIMIT_SETTINGS_POSITION:
//				currentLimitSettings();
//				break;
//
//			case MALF_DEACTIVATE_POSITION:
//				malfDeactivate();
//				break;
//
//			case MALF_ACTIVATE_POSITION:
//				malfActivate();
//				break;
//
//			case HPC_FAN_ON_POSITION:
//				hpcFanOn();
//				break;
//
//			case HPC_FAN_OFF_POSITION:
//				hpcFanOff();
//				break;
//
//				// Alarms
//			case HIGH_TEMP_ALARM_POSITION: case LOW_TEMP_ALARM_POSITION:
//			case DOOR_ALARM_POSITION: case PHASE_MISSING_ALARM_POSITION: case EVAP_MI_THERMAL_OVERLOAD_ALARM_POSITION:
//			case CONDENSOR_MI_THERMAL_OVERLOAD_ALARM_POSITION: case COMPRESSOR_THERMAL_OVERLOAD_ALARM_POSITION:
//			case OVER_VOLTAGE_ALARM_POSITION: case UNDER_VOLTAGE_ALARM_POSITION:
//			case BAD_BOARD_ALARM_POSITION: case HIGH_PRESSURE_ALARM_POSITION:
//			case LOW_PRESSURE_ALARM_POSITION: case FROST_ALARM_POSITION:
//			case DISABLE_SWITCH_ALARM_POSITION: case COIL_TEMP_SENSOR_FAULT_ALARM_POSITION:
//			case INLET_TEMP_SENSOR_FAULT_ALARM_POSITION: case OUTLET_TEMP_SENSOR_FAULT_ALARM_POSITION:
//			case OVER_CURRENT_ALARM_POSITION: case COMPRESSOR_RESTART_DELAY_COUNT_DOWN_POSITION: case COMPRESSOR_RESTART_DELAY_TIMER_POSITION:
//				showAlarm(currentPosition.displayLevel);
//				break;

		default: break;
	}
}
