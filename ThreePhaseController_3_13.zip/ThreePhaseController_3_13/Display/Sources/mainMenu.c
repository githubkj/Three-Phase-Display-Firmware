#include "menu.h"
#include "mainMenu.h"
#include "screen.h"
#include "digit.h"
#include "text.h"
#include "OLED.h"
#include "button.h"
#include "icon.h"
#include "stdbool.h"
#include "displayMemory.h"
#include "display_UART.h"
#include "PE_Types.h"
#include "Events.h"

uint16_union modbus_rw_reg_rcv[RW_REG_LEN];					// read/write registers controller copy
uint16_union modbus_ro_reg_rcv[RO_REG_LEN];					// read only registers controller copy
uint16_union modbus_wo_reg_snd[WO_REG_LEN];					// write only display firmware and hardware revision registers
byte modbus_rw_coil_rcv[RW_COIL_LEN/8+1];					// read/write coils controller copy

#define USER_LEVEL_PASSWORD		0
#define SYSTEM_LEVEL_PASSWORD	1

void mainMenu(void)
{
	char *mainMenuItems[] = {
			"       Main Menu       ",
			"   User Interface",
			"   System Interface",
			"   About"
	};

    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = MAIN_SCREEN_POSITION;
        currentPosition.lineNumber   = INLET_LINENUM;
//        clearDisplay();
//        displayMemoryNeedsUpdate = true;
    }
    else if (releasedOK)
    {
    	releasedOK = false;
        switch (currentPosition.lineNumber)
        {
			case 1:
				if (modbus_rw_coil_rcv[PASSWORD_ENABLED/8] & PASSWORD_ENABLED_F)
				{
					userInput = 0;
					currentPosition.displayLevel = USER_PASSWORD_POSITION;
				}
				else
				{
					currentPosition.displayLevel = USER_INTERFACE_POSITION;
				}
				break;

			case 2:
				userInput = 0;
				currentPosition.displayLevel = SYSTEM_PASSWORD_POSITION;
				break;

			case 3:
				currentPosition.displayLevel = ABOUT_POSITION;
				break;

			default: break;
        }
        currentPosition.lineNumber = 1;
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (releasedUp)
    {
    	releasedUp = false;
		switch (currentPosition.lineNumber)
		{
			case 1: case 2:
				currentPosition.lineNumber = 1;
				break;

			case 3:
				currentPosition.lineNumber = 2;
				break;

			default: break;
		}
//		displayMemoryNeedsUpdate = true;
    }
    else if (releasedDown)
    {
    	releasedDown = false;
		switch (currentPosition.lineNumber)
		{
			case 1:
				currentPosition.lineNumber = 2;
				break;

			case 2: case 3:
				currentPosition.lineNumber = 3;
				break;

			default: break;
		}
//		displayMemoryNeedsUpdate = true;
    }
    else
    {
		displayHighlightedString(mainMenuItems[0], arial_bold14, 0, 0);
		displayString(mainMenuItems[1], arial14, 2, 0);
		displayString(mainMenuItems[2], arial14, 4, 0);
		displayString(mainMenuItems[3], arial14, 6, 0);

		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
    }
}

void enterPassword(void)
{
    if (releasedBack)
    {
    	releasedBack = false;
        currentPosition.displayLevel = MAIN_MENU_POSITION;
        currentPosition.lineNumber   = 1;
//        clearDisplay();
//        displayMemoryNeedsUpdate = true;
    }
    else if (releasedOK)
    {
    	releasedOK = false;
//    	clearDisplay();
    	if ((userInput == USER_LEVEL_PASSWORD) && (currentPosition.displayLevel == USER_PASSWORD_POSITION))
    	{
            currentPosition.displayLevel = USER_INTERFACE_POSITION;
            currentPosition.lineNumber   = 1;
//            displayMemoryNeedsUpdate = true;
    	}
    	else if ((userInput == SYSTEM_LEVEL_PASSWORD) && (currentPosition.displayLevel == SYSTEM_PASSWORD_POSITION))
    	{
            currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
            currentPosition.lineNumber   = 1;
//            displayMemoryNeedsUpdate = true;
    	}
    	else
    	{
            currentPosition.displayLevel = MAIN_MENU_POSITION;
            currentPosition.lineNumber   = 1;
//            displayMemoryNeedsUpdate = true;
    	}
    }
    else if (pressedUp && !heldUp)
	{
		if (updateScreenTimerDone)
		{
			userInput += 1;
	    	if (userInput > 99)
	    	{
	    		userInput = 0;
	    	}
			showIntegerLeftAligned(digitCalibri5x30, userInput, 5, 30, 3, 35);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 4000;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldUp)
	{
		if (updateScreenTimerDone)
		{
			userInput += 1;
	    	if (userInput > 99)
	    	{
	    		userInput = 0;
	    	}
			showIntegerLeftAligned(digitCalibri5x30, userInput, 5, 30, 3, 35);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 500;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else if (pressedDown && !heldDown)
	{
		if (updateScreenTimerDone)
		{
			userInput -= 1;
	    	if (userInput < 0)
	    	{
	    		userInput = 99;
	    	}
			showIntegerLeftAligned(digitCalibri5x30, userInput, 5, 30, 3, 35);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 4000;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
	else if (heldDown)
	{
		if (updateScreenTimerDone)
		{
			userInput -= 1;
	    	if (userInput < 0)
	    	{
	    		userInput = 99;
	    	}
			showIntegerLeftAligned(digitCalibri5x30, userInput, 5, 30, 3, 35);
	        updateScreen = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 500;
				TI1_updateScreenTimerIsOn = true;
			}
		}
	}
    else
    {
    	displayHighlightedString("    Enter Password    ", arial_bold14, 0, 0);
		showIntegerLeftAligned(digitCalibri5x30, userInput, 5, 30, 3, 35);
        updateScreen = true;
    }
}

void userInterfaceMenu(void)
{
	char *userInterfaceItems[] = {
			"     User Interface     ",
			"   Cooling Set Point",
			"   Cooling Differential",
			"   Heating Set Point",
			"   Heating Differential",
			"   High Temp Alarm",
			"   Low Temp Alarm",
			"   Temperature Scale",
			"   Hysteresis ",
			"   Language",
			"   Password"
	};

    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = MAIN_MENU_POSITION;
        currentPosition.lineNumber   = 1;
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	parameterIsSet = false;
        switch (currentPosition.lineNumber)
        {
            case 1:
                currentPosition.displayLevel = COOLING_SET_POINT_POSITION;
            	userInput = modbus_rw_reg_rcv[COOLING_SP].ivalue;
                break;

            case 2:
                currentPosition.displayLevel = COOLING_DIF_POSITION;
            	userInput = modbus_rw_reg_rcv[COOLING_DIF_1].ivalue;
                break;

            case 3:
                currentPosition.displayLevel = HEATING_SET_POINT_POSITION;
            	userInput = modbus_rw_reg_rcv[HEATING_SP].ivalue;
                break;

            case 4:
                currentPosition.displayLevel = HEATING_DIF_POSITION;
            	userInput = modbus_rw_reg_rcv[HEATING_DIF].ivalue;
                break;

            case 5:
                currentPosition.displayLevel = HIGH_TEMP_ALARM_SP_POSITION;
            	userInput = modbus_rw_reg_rcv[HIGH_TEMP_ALARM_SP].ivalue;
                break;

            case 6:
                currentPosition.displayLevel = LOW_TEMP_ALARM_SP_POSITION;
            	userInput = modbus_rw_reg_rcv[LOW_TEMP_ALARM_SP].ivalue;
                break;

            case 7:
                currentPosition.displayLevel = TEMP_SCALE_POSITION;
				if (modbus_rw_coil_rcv[UNIT_OF_MEASURE/8] & UNIT_OF_MEASURE_F)
				{
					currentPosition.lineNumber = 1; // Degree F
				}
				else
				{
					currentPosition.lineNumber = 2; // Degree C
				}
                break;

            case 8:
            	currentPosition.displayLevel = HYSTERESIS_POSITION;
				if (modbus_rw_coil_rcv[COOL_HYSTERESIS/8] & COOL_HYSTERESIS_F)
				{
					currentPosition.lineNumber = 2; // Negative
				}
				else
				{
					currentPosition.lineNumber = 1; // Positive
				}
                break;

            case 9:
            	currentPosition.displayLevel = LANGUAGE_MENU_POSITION;
				currentPosition.lineNumber = 1;
            	break;

            case 10:
            	currentPosition.displayLevel = PASSWORD_POSITION;
				if (modbus_rw_coil_rcv[PASSWORD_ENABLED/8] & PASSWORD_ENABLED_F)
				{
					currentPosition.lineNumber = 2;
				}
				else
				{
					currentPosition.lineNumber = 1;
				}
                break;

            default:
                break;
        }
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedUp)
    {
		if (updateScreenTimerDone)
		{
	    	if (currentPosition.lineNumber > 1)
	    	{
	            currentPosition.lineNumber -= 1;
	    	}
	    	else
	    	{
	            currentPosition.lineNumber = 1;
	        }
	    	displayMemoryNeedsUpdate = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 4000;
				TI1_updateScreenTimerIsOn = true;
			}
		}
    }
    else if (pressedDown)
    {
		if (updateScreenTimerDone)
		{
			if (currentPosition.lineNumber < 10)
			{
				currentPosition.lineNumber += 1;
			}
			else
			{
				currentPosition.lineNumber = 10;
			}
	    	displayMemoryNeedsUpdate = true;
			updateScreenTimerDone = false;
		}
		else
		{
			if (!TI1_updateScreenTimerIsOn)
			{
				updateScreenRate = 4000;
				TI1_updateScreenTimerIsOn = true;
			}
		}
    }
//else if (pressedUp)
//    {
//    	pressedUp = false;
//    	if (currentPosition.lineNumber > 1)
//    	{
//            currentPosition.lineNumber -= 1;
//    	}
//    	else
//    	{
//            currentPosition.lineNumber = 1;
//        }
//        clearDisplay();
//        displayMemoryNeedsUpdate = true;
//    }
//    else if (pressedDown)
//    {
//    	pressedDown = false;
//    	if (currentPosition.lineNumber < 10)
//    	{
//            currentPosition.lineNumber += 1;
//    	}
//    	else
//    	{
//            currentPosition.lineNumber = 10;
//        }
//        clearDisplay();
//        displayMemoryNeedsUpdate = true;
//    }
    else
    {
		displayHighlightedString(userInterfaceItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
			case 1: case 2: case 3:
				displayString(userInterfaceItems[1], arial14, 2, 0);
				displayString(userInterfaceItems[2], arial14, 4, 0);
				displayString(userInterfaceItems[3], arial14, 6, 0);
				break;

			case 4: case 5: case 6:
				displayString(userInterfaceItems[4], arial14, 2, 0);
				displayString(userInterfaceItems[5], arial14, 4, 0);
				displayString(userInterfaceItems[6], arial14, 6, 0);
				break;

			case 7: case 8: case 9:
				displayString(userInterfaceItems[7], arial14, 2, 0);
				displayString(userInterfaceItems[8], arial14, 4, 0);
				displayString(userInterfaceItems[9], arial14, 6, 0);
				break;

			case 10:
				displayString(userInterfaceItems[10], arial14, 2, 0);
				break;

			default: break;
        }
		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
    }
}

void systemInterfaceMenu(void)
{
	char *systemInterfaceItems[] = {
			"   System Interface   ",
			"   Door/Smoke Alarm",
			"   Disable Switch",
			"   Alarm relay output",
			"   Comp Restart Delay",
			"   Compressor Current",
			"   Display SYS Settings"
	};

    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = MAIN_MENU_POSITION;
        currentPosition.lineNumber   = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	parameterIsSet = false;
        switch (currentPosition.lineNumber)
        {
            case 1:
                currentPosition.displayLevel = DOOR_SMOKE_ALARM_POSITION;
				if (modbus_rw_coil_rcv[DOOR_SWITCH/8] & DOOR_SWITCH_F)
				{
					currentPosition.lineNumber = 2;
				}
				else
				{
					currentPosition.lineNumber = 1;
				}
                break;

            case 2:
                currentPosition.displayLevel = DISABLE_SWITCH_POSITION;
				if (modbus_rw_coil_rcv[DISABLE_SWITCH/8] & DISABLE_SWITCH_F)
				{
					currentPosition.lineNumber = 2;
				}
				else
				{
					currentPosition.lineNumber = 1;
				}
                break;

            case 3:
                currentPosition.displayLevel = ALARM_RELAY_OUTPUT_POSITION;
				if (modbus_rw_coil_rcv[ALARM_OUTPUT/8] & ALARM_OUTPUT_F)
				{
					currentPosition.lineNumber = 2;
				}
				else
				{
					currentPosition.lineNumber = 1;
				}
                break;

            case 4:
            	currentPosition.displayLevel = COMPRESSOR_RESTART_DELAY_POSITION;
            	userInput = modbus_rw_reg_rcv[COMP_MIN_STOP_TIME].ivalue;
                break;

            case 5:
                currentPosition.displayLevel = COMPRESSOR_CURRENT_POSITION;
                currentPosition.lineNumber = 1;
                break;

            case 6:
                currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
                currentPosition.lineNumber = 1;
            	break;

            default:
                break;
        }
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    	if (currentPosition.lineNumber > 1)
    	{
            currentPosition.lineNumber -= 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 1;
        }
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    	if (currentPosition.lineNumber < 6)
    	{
            currentPosition.lineNumber += 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 6;
        }
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else
    {
		displayHighlightedString(systemInterfaceItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
            case 1: case 2: case 3:
				displayString(systemInterfaceItems[1], arial14, 2, 0);
				displayString(systemInterfaceItems[2], arial14, 4, 0);
				displayString(systemInterfaceItems[3], arial14, 6, 0);
                break;

            case 4: case 5: case 6:
				displayString(systemInterfaceItems[4], arial14, 2, 0);
				displayString(systemInterfaceItems[5], arial14, 4, 0);
				displayString(systemInterfaceItems[6], arial14, 6, 0);
                break;

            default: break;
        }
		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
    }
}

void showVersionNumber(int versionNumber, char page, char col)
{
	char minor = versionNumber & 0xff;
	char major = (versionNumber & 0xff00) >> 8;
	displayChar(major, arial14, page, col);
	displayChar('.', arial14, page, col+8);
	displayChar(minor, arial14, page, col+16);
}

void aboutMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = MAIN_MENU_POSITION;
        currentPosition.lineNumber   = ABOUT_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    }
    else
    {
    	displayString(" ECU Hardware:", arial14, 0, 0);
    	showVersionNumber(modbus_ro_reg_rcv[HARDWARE_VERSION].ivalue, 0, 90);
        displayString(" ECU Firmware:", arial14, 2, 0);
    	showVersionNumber(modbus_ro_reg_rcv[FIRMWARE_VERSION].ivalue, 2, 90);
    	displayString(" DU Hardware:", arial14, 4, 0);
    	showVersionNumber(modbus_wo_reg_snd[DISPLAY_HARDWARE_REV].ivalue, 4, 90);
    	displayString(" DU Firmware:", arial14, 6, 0);
    	showVersionNumber(modbus_wo_reg_snd[DISPLAY_FIRMWARE_REV].ivalue, 6, 90);

    	updateScreen = true;
    }
}
