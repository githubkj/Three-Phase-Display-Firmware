#ifndef __DIGIT_H
#define __DIGIT_H

extern const char digitCalibriLight4x31[];
extern const char digitCalibriBold5x30[];
extern const char digitCalibriLight5x30[];
extern const char digitCalibri5x30[];
extern const char digitCourier2x7[];
extern const char digitSevenSegment6x24[];

/* Function Prototypes */

	void showDigit(const char font[], unsigned char digit, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column);
	void showHighlightedDigit(const char font[], unsigned char digit, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column);
	void showIntegerRightAligned(const char font[], int number, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column);
	void showIntegerLeftAligned(const char font[], int number, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column);

	void clearDigit(unsigned char widthInRows, unsigned char heightInPages, unsigned char page, unsigned char column);
	void showNumber(const char digit[], int number, unsigned char page, unsigned char column);
	void showSmallDigit(const char font[], unsigned char digit, unsigned char page, unsigned char column);
	void showSmallHighlightedDigit(const char digit[], unsigned char num, unsigned char page, unsigned char column);
	void showSmallNumber(const char digit[], int number, unsigned char page, unsigned char column);
	void show_calibri_Digit(unsigned char digit, unsigned char page, unsigned char column);
	void show_calibri_Number(int number, unsigned char page, unsigned char column);

#endif /* __DIGIT_H */
