#ifndef __SERVICE_MENU_H
#define __SERVICE_MENU_H

void doorSmokeAlarmMenu(void);
void disableSwitchAlarmMenu(void);
void alarmRelayOutput(void);
void compressorRestartDelay(void);
void compressorCurrent(void);
void displaySystemSettings(void);
void currentLimitSettings(void);
void malfActivate(void);
void malfDeactivate(void);
void hpcFanOn(void);
void hpcFanOff(void);

#endif /* __SERVICE_MENU_H */
