#include "menu.h"
#include "serviceMenu.h"
#include "screen.h"
#include "digit.h"
#include "text.h"
#include "OLED.h"
#include "button.h"
#include "icon.h"
#include "stdbool.h"
#include "displayMemory.h"
#include "display_UART.h"
#include "PE_Types.h"
#include "Events.h"

uint16_union modbus_ro_reg_rcv[RO_REG_LEN];					// read only registers controller copy
uint16_union modbus_ero_reg_rcv[ERO_REG_LEN+1];			// extended read only registers

void doorSmokeAlarmMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DOOR_SWITCH, false, 0, 0, DOOR_SWITCH_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DOOR_SWITCH, true, 0, 0, DOOR_SWITCH_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("  Door/Smoke Alarm", arial_bold14, 2, 0);
    	    		displayString("  is Normally Open", arial_bold14, 4, 0);
    				break;

    			case 2: // Normally Close
    	    		displayString("  Door/Smoke Alarm", arial_bold14, 2, 0);
    	    		displayString("  is Normally Close", arial_bold14, 4, 0);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("   Door/Smoke Alarm   ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("  Normally Close", arial14, 4, 0);
    				break;

    			case 2:
    				displayString("  Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;

    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void disableSwitchAlarmMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DISABLE_SWITCH, false, 0, 0, DISABLE_SWITCH_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + DISABLE_SWITCH, true, 0, 0, DISABLE_SWITCH_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
    	clearDisplay();
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
    	clearDisplay();
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("  Disable Switch", arial_bold14, 2, 5);
    	    		displayString("  is Normally Open", arial_bold14, 4, 5);
    				break;

    			case 2: // Normally Close
    	    		displayString("  Disable Switch", arial_bold14, 2, 5);
    	    		displayString("  is Normally Close", arial_bold14, 4, 5);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("    Disable Switch    ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("  Normally Close", arial14, 4, 0);
    				break;
    			case 2:
    				displayString("  Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;
    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void alarmRelayOutput(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 3;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // Normally open
				uart_write_return = display_uart_update(COIL, RW_COIL_START + ALARM_OUTPUT, false, 0, 0, ALARM_OUTPUT_F);
				break;

			case 2: // Normally close
				uart_write_return = display_uart_update(COIL, RW_COIL_START + ALARM_OUTPUT, true, 0, 0, ALARM_OUTPUT_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
    	clearDisplay();
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
    	clearDisplay();
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Normally Open
    	    		displayString("Alarm Relay Output", arial_bold14, 2, 10);
    	    		displayString("is Normally Open", arial_bold14, 4, 10);
    				break;

    			case 2: // Normally Close
    	    		displayString("Alarm Relay Output", arial_bold14, 2, 10);
    	    		displayString("is Normally Close", arial_bold14, 4, 10);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("  Alarm Relay Output  ", arial_bold14, 0, 0);
        	switch (currentPosition.lineNumber)
        	{
    			case 1:
    				displayString(" * Normally Open", arial14, 2, 0);
    				displayString("  Normally Close", arial14, 4, 0);
    				break;
    			case 2:
    				displayString("  Normally Open", arial14, 2, 0);
    				displayString(" * Normally Close", arial14, 4, 0);
    				break;
    			default: break;
        	}
    	}
		updateScreen = true;
    }
}

void compressorRestartDelay(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber = 4;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COMP_MIN_STOP_TIME, false, userInput, COMP_MIN_STOP_TIME_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		userInput += 1;
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		userInput -= 1;
        displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Comp Restart Delay", arial_bold14, 2, 5);
        	displayString("is set to:", arial_bold14, 4, 5);
        	userInput = modbus_rw_reg_rcv[COMP_MIN_STOP_TIME].ivalue;
        	unsigned char numberColumn = 65;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput, 4, numberColumn);
        	}
        	displayString("sec", arial_bold14, 4, 95);
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

			int minute = userInput / 60;
			int second = userInput % 60;

			if (minute >= 100)
			{
				minute = 99;
			}
			else if (minute <= -1)
			{
				minute = 0;
			}

			if (second >= 100)
			{
				second = 99;
			}
			else if (second <= -1)
			{
				second = 0;
			}

			showNumber(digit24_48, minute, 2, 5);

			showIcon(decimal_point, 4, 2, 65);
			showIcon(decimal_point, 4, 4, 65);

			showNumber(digit24_48, second, 2, 70);

//    		if (userInput >= 1000)
//    		{
//    			numberColumn = 15;
//    		}
//    		else if (userInput < 1000 && userInput >= 100)
//    		{
//    			numberColumn = 30;
//    		}
//    		else if (userInput < 100 && userInput >= 0)
//    		{
//    			numberColumn = 20;
//    		}
//    		else if (userInput < 0 && userInput > -100)
//    		{
//    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
//    			numberColumn = 50;
//    		}
//    		else if (userInput <= -100 && userInput > -1000)
//    		{
//    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
//    			numberColumn = 35;
//    		}
//    		else if (userInput <= -1000)
//    		{
//    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
//    			numberColumn = 20;
//    		}
//
//    		showNumber(digit24_48, userInput, 2, numberColumn);
//    		if (userInput < 100 && userInput >= 0)
//    		{
//    			clearDigit(2,20);
//			}
    		// Title
    		displayHighlightedString(" Comp Restart Delay ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void compressorCurrent(void)
{
	uint16 uart_write_return;

    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 5;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    }
    else
    {
    	int phase1Current = modbus_ro_reg_rcv[PHASE_1_CURRENT].ivalue/10;
    	int phase2Current = modbus_ro_reg_rcv[PHASE_2_CURRENT].ivalue/10;
    	int phase3Current = modbus_ro_reg_rcv[PHASE_3_CURRENT].ivalue/10;

    	displayHighlightedString(" Compressor Current ", arial_bold14, 0, 0);
		displayString("Phase 1:", arial_bold14, 2, 0);
		displayString("Phase 2:", arial_bold14, 4, 0);
		displayString("Phase 3:", arial_bold14, 6, 0);
		showSmallNumber(digit_courier7x14, phase3Current, 6, 70);

		if (phase1Current <= 99)
		{
			showSmallNumber(digit_courier7x14, phase1Current, 2, 70);
			displayString("mA", arial_bold14, 2, 100);
		}
		else
		{
			showSmallNumber(digit_courier7x14, phase1Current/1000, 2, 70);
			displayString(".", courier7x14, 2, 78); // decimal point
			showSmallNumber(digit_courier7x14, (phase1Current-(phase1Current/1000)*1000)/100, 2, 85);
			displayString("A", arial_bold14, 2, 100);
		}

		if (phase2Current <= 99)
		{
			showSmallNumber(digit_courier7x14, phase2Current, 4, 70);
			displayString("mA", arial_bold14, 4, 100);
		}
		else
		{
			showSmallNumber(digit_courier7x14, phase2Current/1000, 4, 70);
			displayString(".", courier7x14, 4, 78); // decimal point
			showSmallNumber(digit_courier7x14, (phase2Current-(phase2Current/1000)*1000)/100, 4, 85);
			displayString("A", arial_bold14, 4, 100);
		}

		if (phase3Current <= 99)
		{
			showSmallNumber(digit_courier7x14, phase3Current, 6, 70);
			displayString("mA", arial_bold14, 6, 100);
		}
		else
		{
			showSmallNumber(digit_courier7x14, phase3Current/1000, 6, 70);
			displayString(".", courier7x14, 6, 78); // decimal point
			showSmallNumber(digit_courier7x14, (phase3Current-(phase3Current/1000)*1000)/100, 6, 85);
			displayString("A", arial_bold14, 6, 100);
		}

        updateScreen = true;
    }
}

void displaySystemSettings(void)
{
	char *systemSettingItems[] = {
			" Display SYS Settings ",
	    	"   Current limit setting",
	        "   MALF Activate",
	        "   MALF Deactivate",
	        "   MALF Deactivate",
	    	"   HPC Fan ON",
	    	"   HPC Fan OFF"
	};

	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = SYSTEM_INTERFACE_POSITION;
        currentPosition.lineNumber   = 6;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedUp)
	{
    	pressedUp = false;
    	if (currentPosition.lineNumber == 1)
    	{
            currentPosition.lineNumber = 5;
    	}
    	else
    	{
            currentPosition.lineNumber -= 1;
        }
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
	else if (pressedDown)
	{
    	pressedDown = false;
    	if (currentPosition.lineNumber == 5)
    	{
            currentPosition.lineNumber = 1;
    	}
    	else
    	{
            currentPosition.lineNumber += 1;
        }
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
        switch (currentPosition.lineNumber)
        {
            case 1:
                currentPosition.displayLevel = CURRENT_LIMIT_SETTINGS_POSITION;
                displayMemoryNeedsUpdate = true;
                break;

            case 2:
            	userInput = modbus_ero_reg_rcv[MALF_ACTIVATE].ivalue;
                currentPosition.displayLevel = MALF_ACTIVATE_POSITION;
                displayMemoryNeedsUpdate = true;
                break;

            case 3:
            	userInput = modbus_ero_reg_rcv[MALF_DEACTIVATE].ivalue;
                currentPosition.displayLevel = MALF_DEACTIVATE_POSITION;
                displayMemoryNeedsUpdate = true;
                break;

            case 4:
            	userInput = modbus_ero_reg_rcv[HPC_DEACTIVATE].ivalue;
                currentPosition.displayLevel = HPC_FAN_ON_POSITION;
                displayMemoryNeedsUpdate = true;
                break;

            case 5:
            	userInput = modbus_ero_reg_rcv[HPC_ACTIVATE].ivalue;
                currentPosition.displayLevel = HPC_FAN_OFF_POSITION;
                displayMemoryNeedsUpdate = true;
                break;

            default: break;
        }
        clearDisplay();
	}
	else
	{
		displayHighlightedString(systemSettingItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
            case 1:
            case 2:
            case 3:
        		displayString(systemSettingItems[1], arial14, 2, 0);
        		displayString(systemSettingItems[2], arial14, 4, 0);
        		displayString(systemSettingItems[3], arial14, 6, 0);
                break;

            case 4:
            case 5:
        		displayString(systemSettingItems[4], arial14, 2, 0);
        		displayString(systemSettingItems[5], arial14, 4, 0);
                break;

            default: break;
        }
		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
	}
}

void currentLimitSettings(void)
{
	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedUp)
	{
		pressedUp = false;
	}
	else if (pressedDown)
	{
		pressedDown = false;
	}
	else
	{
		displayHighlightedString(" Current limit setting ", arial_bold14, 0, 0);
    	unsigned char numberColumn;

    	int currentLimit = modbus_ero_reg_rcv[4].ivalue/10;

		if (currentLimit <= 99)
		{
			showSmallNumber(digit_courier7x14, currentLimit, 3, 30);
			displayString("mA", arial_bold14, 3, 60);
		}
		else
		{
			showSmallNumber(digit_courier7x14, currentLimit/1000, 3, 30);
			displayString(".", courier7x14, 3, 38); // decimal point
			showSmallNumber(digit_courier7x14, (currentLimit-(currentLimit/1000)*1000)/100, 3, 45);
			displayString("A", arial_bold14, 3, 60);
		}

        /* Set the updateScreen flag */
        updateScreen = true;
	}
}

void malfActivate(void)
{
	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
	}
	else if (pressedUp)
	{
		pressedUp = false;
	}
	else if (pressedDown)
	{
		pressedDown = false;
	}
	else
	{
		displayHighlightedString("    MALF Activate     ", arial_bold14, 0, 0);
		unsigned char numberColumn;

		if (userInput >= 1000)
		{
			numberColumn = 15;
    		showDegree(2,110);
		}
		else if (userInput < 1000 && userInput >= 100)
		{
			numberColumn = 30;
    		showDegree(2,95);
		}
		else if (userInput < 100 && userInput >= 0)
		{
			numberColumn = 20;
    		showDegree(2,85);
		}
		else if (userInput < 0 && userInput > -100)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
			numberColumn = 50;
    		showDegree(2,85);
		}
		else if (userInput <= -100 && userInput > -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
			numberColumn = 35;
    		showDegree(2,90);
		}
		else if (userInput <= -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
			numberColumn = 20;
    		showDegree(2,115);
		}

		showNumber(digit24_48, userInput/100, 2, numberColumn);
		if (userInput < 100 && userInput >= 0)
		{
			clearDigit(2,20);
		}
        updateScreen = true;
	}
}

void malfDeactivate(void)
{
	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 3;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
	}
	else if (pressedUp)
	{
		pressedUp = false;
	}
	else if (pressedDown)
	{
		pressedDown = false;
	}
	else
	{
		displayHighlightedString("   MALF Deactivate   ", arial_bold14, 0, 0);
		unsigned char numberColumn;

		if (userInput >= 1000)
		{
			numberColumn = 15;
    		showDegree(2,110);
		}
		else if (userInput < 1000 && userInput >= 100)
		{
			numberColumn = 30;
    		showDegree(2,95);
		}
		else if (userInput < 100 && userInput >= 0)
		{
			numberColumn = 20;
    		showDegree(2,85);
		}
		else if (userInput < 0 && userInput > -100)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
			numberColumn = 50;
    		showDegree(2,85);
		}
		else if (userInput <= -100 && userInput > -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
			numberColumn = 35;
    		showDegree(2,90);
		}
		else if (userInput <= -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
			numberColumn = 20;
    		showDegree(2,115);
		}

		showNumber(digit24_48, userInput/100, 2, numberColumn);
		if (userInput < 100 && userInput >= 0)
		{
			clearDigit(2,20);
		}
        updateScreen = true;
	}
}

void hpcFanOn(void)
{
	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 4;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 4;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedUp)
	{
		pressedUp = false;
	}
	else if (pressedDown)
	{
		pressedDown = false;
	}
	else
	{
		displayHighlightedString("      HPC Fan ON      ", arial_bold14, 0, 0);

		unsigned char numberColumn;

		if (userInput >= 1000)
		{
			numberColumn = 15;
    		showDegree(2,110);
		}
		else if (userInput < 1000 && userInput >= 100)
		{
			numberColumn = 30;
    		showDegree(2,95);
		}
		else if (userInput < 100 && userInput >= 0)
		{
			numberColumn = 20;
    		showDegree(2,85);
		}
		else if (userInput < 0 && userInput > -100)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
			numberColumn = 50;
    		showDegree(2,85);
		}
		else if (userInput <= -100 && userInput > -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
			numberColumn = 35;
    		showDegree(2,90);
		}
		else if (userInput <= -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
			numberColumn = 20;
    		showDegree(2,115);
		}

		showNumber(digit24_48, userInput/100, 2, numberColumn);
		if (userInput < 100 && userInput >= 0)
		{
			clearDigit(2,20);
		}
        updateScreen = true;
	}
}

void hpcFanOff(void)
{
	if (pressedBack && !buttonHold)
	{
		pressedBack = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 5;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
		pressedOK = false;
        currentPosition.displayLevel = DISPLAY_SYS_SETTINGS_MENU_POSITION;
        currentPosition.lineNumber   = 5;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedUp)
	{
		pressedUp = false;
	}
	else if (pressedDown)
	{
		pressedDown = false;
	}
	else
	{
		unsigned char numberColumn;

		displayHighlightedString("      HPC Fan OFF     ", arial_bold14, 0, 0);

		if (userInput >= 1000)
		{
			numberColumn = 15;
    		showDegree(2,110);
		}
		else if (userInput < 1000 && userInput >= 100)
		{
			numberColumn = 30;
    		showDegree(2,95);
		}
		else if (userInput < 100 && userInput >= 0)
		{
			numberColumn = 20;
    		showDegree(2,85);
		}
		else if (userInput < 0 && userInput > -100)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
			numberColumn = 50;
    		showDegree(2,85);
		}
		else if (userInput <= -100 && userInput > -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
			numberColumn = 35;
    		showDegree(2,90);
		}
		else if (userInput <= -1000)
		{
			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
			numberColumn = 20;
    		showDegree(2,115);
		}

		showNumber(digit24_48, userInput/100, 2, numberColumn);
		if (userInput < 100 && userInput >= 0)
		{
			clearDigit(2,20);
		}
        updateScreen = true;
	}
}
