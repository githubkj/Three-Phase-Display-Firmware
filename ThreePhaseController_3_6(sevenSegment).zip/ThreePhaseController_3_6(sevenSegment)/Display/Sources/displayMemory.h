#ifndef __DISPLAY_MEMORY_H
#define __DISPLAY_MEMORY_H

extern _Bool displayMemoryNeedsUpdate;

void updateDisplayMemory(void);

#endif /* __DISPLAY_MEMORY_H */
