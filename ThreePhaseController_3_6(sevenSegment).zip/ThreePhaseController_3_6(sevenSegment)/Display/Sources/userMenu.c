#include "menu.h"
#include "userMenu.h"
#include "screen.h"
#include "digit.h"
#include "text.h"
#include "OLED.h"
#include "button.h"
#include "icon.h"
#include "stdbool.h"
#include "displayMemory.h"
#include "display_UART.h"
#include "PE_Types.h"
#include "Events.h"

uint16_union modbus_rw_reg_rcv[RW_REG_LEN];					// read/write registers controller copy
byte modbus_rw_coil_rcv[RW_COIL_LEN/8+1];					// read/write coils controller copy

void coolingSPMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = COOLING_SP_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COOLING_SP, false, userInput, COOLING_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		if (userInput < modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
		{
			userInput += 10;
			if (userInput > modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue)
			{
				userInput = modbus_rw_reg_rcv[COOLING_SP_MAX].ivalue;
			}
			displayMemoryNeedsUpdate = true;
		}
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		displayMemoryNeedsUpdate = true;
		if (userInput > modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
		{
			userInput -= 10;
    		if (userInput < modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue)
    		{
				userInput = modbus_rw_reg_rcv[COOLING_SP_MIN].ivalue;
    		}
			displayMemoryNeedsUpdate = true;
		}
        displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Cooling set point", arial_bold14, 2, 20);
        	displayString("is set to:", arial_bold14, 4, 20);
        	userInput = modbus_rw_reg_rcv[COOLING_SP].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// Title
    		displayHighlightedString("   Cooling Set Point  ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void coolingDifMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = COOLING_DIF_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + COOLING_DIF_1, false, userInput, COOLING_DIF_1_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    	userInput += 10;
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    	userInput -= 10;
        displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Cooling differential", arial_bold14, 2, 10);
        	displayString("is set to:", arial_bold14, 4, 10);
        	userInput = modbus_rw_reg_rcv[COOLING_DIF_1].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// title
    		displayHighlightedString("  Cooling Differential ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void heatingSPMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HEATING_SP_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HEATING_SP, false, userInput, HEATING_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		if (userInput < modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
		{
			userInput += 10;
			if (userInput > modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue)
			{
				userInput = modbus_rw_reg_rcv[HEATING_SP_MAX].ivalue;
			}
			displayMemoryNeedsUpdate = true;
		}
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		displayMemoryNeedsUpdate = true;
		if (userInput > modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
		{
			userInput -= 10;
    		if (userInput < modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue)
    		{
				userInput = modbus_rw_reg_rcv[HEATING_SP_MIN].ivalue;
    		}
			displayMemoryNeedsUpdate = true;
		}
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Heating set point", arial_bold14, 2, 15);
        	displayString("is set to:", arial_bold14, 4, 15);
        	userInput = modbus_rw_reg_rcv[HEATING_SP].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// title
    		displayHighlightedString("   Heating Set Point   ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void heatingDifMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HEATING_DIF_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HEATING_DIF, false, userInput, HEATING_DIF_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    	userInput += 10;
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    	userInput -= 10;
        displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Heating differential", arial_bold14, 2, 10);
        	displayString("is set to:", arial_bold14, 4, 10);
        	userInput = modbus_rw_reg_rcv[HEATING_DIF].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// title
    		displayHighlightedString("  Heating Differential ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void highTempAlarmSPMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HIGH_TEMP_ALARM_LINENUM;
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + HIGH_TEMP_ALARM_SP, false, userInput, HIGH_TEMP_ALARM_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	clearDisplay();
    	TI1_validationScreenTimer_Flag = true;
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    	userInput += 10;
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		userInput -= 10;
		displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("High temp alarm SP", arial_bold14, 2, 10);
        	displayString("is set to:", arial_bold14, 4, 10);
        	userInput = modbus_rw_reg_rcv[HIGH_TEMP_ALARM_SP].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// title
    		displayHighlightedString("  High Temp Alarm SP  ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void lowTempAlarmSPMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = LOW_TEMP_ALARM_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	// write to main board to update the coolingSP
    	uart_write_return = display_uart_update(REGISTER, RW_REG_START + LOW_TEMP_ALARM_SP, false, userInput, LOW_TEMP_ALARM_SP_F, 0);
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		userInput += 10;
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    	userInput -= 10;
        displayMemoryNeedsUpdate = true;
    }
    else
    {
    	if (parameterIsSet)
    	{
        	displayString("Low temp alarm SP", arial_bold14, 2, 10);
        	displayString("is set to:", arial_bold14, 4, 10);
        	userInput = modbus_rw_reg_rcv[LOW_TEMP_ALARM_SP].ivalue;
        	unsigned char numberColumn = 90;
          	if (userInput >= 1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
          	}
          	else if (userInput < 1000 && userInput >= 0)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput < 0 && userInput > -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}
          	else if (userInput <= -1000)
          	{
          		showSmallNumber(digit_courier7x14, userInput/10, 4, numberColumn);
        	}

    		/* degree F/C */
          	unsigned char degreeColumn;
          	if (userInput >= 1000)
          	{
          		degreeColumn = numberColumn+30;
          	}
          	else if (userInput < 1000 && userInput >= 100)
          	{
          		degreeColumn = numberColumn+20;
        	}
          	else if (userInput < 100 && userInput >= 0)
          	{
          		degreeColumn = numberColumn+10;
          	}
          	else if (userInput < 0 && userInput > -100)
          	{
          		degreeColumn = numberColumn+20;
          	}
          	else if (userInput <= -100 && userInput > -1000)
          	{
          		degreeColumn = numberColumn+30;
        	}
          	else if (userInput <= -1000)
          	{
          		degreeColumn = numberColumn+40;
        	}

    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE] & UNIT_OF_MEASURE_F)
    		{
    			showIcon(degreeF, 8, 4, degreeColumn);
    		}
    		else
    		{
    			showIcon(degreeC, 8, 4, degreeColumn);
    		}
    	}
    	else
    	{
    		unsigned char numberColumn;

    		clearDisplay();

    		if (userInput >= 1000)
    		{
    			numberColumn = 15;
        		showDegree(2,110);
    		}
    		else if (userInput < 1000 && userInput >= 100)
    		{
    			numberColumn = 30;
        		showDegree(2,95);
    		}
    		else if (userInput < 100 && userInput >= 0)
    		{
    			numberColumn = 20;
        		showDegree(2,85);
    		}
    		else if (userInput < 0 && userInput > -100)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 30);
    			numberColumn = 50;
        		showDegree(2,85);
    		}
    		else if (userInput <= -100 && userInput > -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 15);
    			numberColumn = 35;
        		showDegree(2,90);
    		}
    		else if (userInput <= -1000)
    		{
    			showIcon(negative_sign, NEGATIVE_SIGN_WIDTH, 4, 5);
    			numberColumn = 20;
        		showDegree(2,115);
    		}

    		showNumber(digit24_48, userInput/10, 2, numberColumn);
    		if (userInput < 100 && userInput >= 0)
    		{
    			clearDigit(2,20);
			}
    		// title
    		displayHighlightedString("  Low Temp Alarm SP  ", arial_bold14, 0, 0);
    	}
        updateScreen = true;
    }
}

void tempScaleMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = TEMP_SCALE_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // degree F
				uart_write_return = display_uart_update(COIL, RW_COIL_START + UNIT_OF_MEASURE, true, 0, 0, UNIT_OF_MEASURE_F);
				break;

			case 2: // degree C
				uart_write_return = display_uart_update(COIL, RW_COIL_START + UNIT_OF_MEASURE, false, 0, 0, UNIT_OF_MEASURE_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else
    {
    	if (parameterIsSet)
    	{
    		if (modbus_rw_coil_rcv[UNIT_OF_MEASURE/8] & UNIT_OF_MEASURE_F)
    		{
	    		displayString("Set to degree F", arial_bold14, 3, 15);
    		}
    		else
    		{
	    		displayString("Set to degree C", arial_bold14, 3, 15);
    		}
    	}
    	else
    	{
    		displayHighlightedString("  Temperature Scale  ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * Fahrenheit", arial14, 2, 0);
					displayString("  Celsius", arial14, 4, 0);
					break;
				case 2:
					displayString("  Fahrenheit", arial14, 2, 0);
					displayString(" * Celsius", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}

void hysteresisMenu(void)
{
    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = HYSTERESIS_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedOK && !buttonHold)
    {
    	pressedOK = false;
    	uint16 uart_write_return;
    	switch (currentPosition.lineNumber)
    	{
			case 1: // positive
				uart_write_return = display_uart_update(COIL, RW_COIL_START + COOL_HYSTERESIS, false, 0, 0, COOL_HYSTERESIS_F);
				break;

			case 2: // negative
				uart_write_return = display_uart_update(COIL, RW_COIL_START + COOL_HYSTERESIS, true, 0, 0, COOL_HYSTERESIS_F);
				break;

			default: break;
    	}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
    }
    else if (pressedUp)
    {
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else if (pressedDown)
    {
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
    else
    {
    	if (parameterIsSet)
    	{
        	switch (currentPosition.lineNumber)
        	{
    			case 1: // Positive
    	    		displayString("Hysteresis: Positive", arial_bold14, 3, 5);
    				break;

    			case 2: // Negative
    	    		displayString("Hysteresis: Negative", arial_bold14, 3, 5);
    				break;

    			default: break;
        	}
    	}
    	else
    	{
    		displayHighlightedString("      Hysteresis       ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * Positive", arial14, 2, 0);
					displayString("  Negative", arial14, 4, 0);
					break;
				case 2:
					displayString("  Positive", arial14, 2, 0);
					displayString(" * Negative", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}

void languageMenu(void)
{
	char *languageMenuItems[] = {
			"       Language        ",
        	"   English",
            "   Chinese",
            "   French",
			"   German",
            "   Italian",
            "   Polish",
			"   Spanish"
	};

    if (pressedBack && !buttonHold)
    {
    	pressedBack = false;
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber   = LANGUAGE_LINENUM;
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedUp)
    {
    	pressedUp = false;
    	if (currentPosition.lineNumber > 1)
    	{
            currentPosition.lineNumber -= 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 1;
        }
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else if (pressedDown)
    {
    	pressedDown = false;
    	if (currentPosition.lineNumber < 7)
    	{
            currentPosition.lineNumber += 1;
    	}
    	else
    	{
            currentPosition.lineNumber = 7;
        }
        clearDisplay();
        displayMemoryNeedsUpdate = true;
    }
    else
    {
		displayHighlightedString(languageMenuItems[0], arial_bold14, 0, 0);
        switch (currentPosition.lineNumber)
        {
            case 1: case 2: case 3:
        		displayString(languageMenuItems[1], arial14, 2, 0);
        		displayString(languageMenuItems[2], arial14, 4, 0);
        		displayString(languageMenuItems[3], arial14, 6, 0);
                break;

            case 4: case 5: case 6:
        		displayString(languageMenuItems[4], arial14, 2, 0);
        		displayString(languageMenuItems[5], arial14, 4, 0);
        		displayString(languageMenuItems[6], arial14, 6, 0);
                break;

            case 7:
        		displayString(languageMenuItems[7], arial14, 2, 0);
                break;

            default: break;
        }

		if (currentPosition.lineNumber%3 == 0)
		{
			displayString(" *", arial14, 6, 0);
		}
		else
		{
			displayString(" *", arial14, (currentPosition.lineNumber%3)*2, 0);
		}
		updateScreen = true;
    }
}

void passwordMenu(void)
{
	if (pressedBack && !buttonHold)
	{
        currentPosition.displayLevel = USER_INTERFACE_POSITION;
        currentPosition.lineNumber = PASSWORD_LINENUM;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
	}
	else if (pressedOK && !buttonHold)
	{
    	uint16 uart_write_return;
		pressedOK = false;
		switch (currentPosition.lineNumber)
		{
		case 1:
			uart_write_return = display_uart_update(COIL, RW_COIL_START + PASSWORD_ENABLED, false, 0, 0, PASSWORD_ENABLED_F);
			break;

		case 2:
			uart_write_return = display_uart_update(COIL, RW_COIL_START + PASSWORD_ENABLED, true, 0, 0, PASSWORD_ENABLED_F);
			break;

		default: break;
		}
    	// Validation Screen
    	parameterIsSet = true;
    	TI1_validationScreenTimer_Flag = true;
    	clearDisplay();
	}
	else if (pressedUp)
	{
    	pressedUp = false;
		currentPosition.lineNumber = 1;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
	else if (pressedDown)
	{
    	pressedDown = false;
		currentPosition.lineNumber = 2;
        displayMemoryNeedsUpdate = true;
        clearDisplay();
    }
	else
	{
    	if (parameterIsSet)
    	{
    		if (currentPosition.lineNumber == 2)
			{
	    		displayString("  Password for User", arial_bold14, 2, 0);
	    		displayString("  Interface is ON", arial_bold14, 4, 0);
			}
			else if (currentPosition.lineNumber == 1)
			{
				displayString("  Password for User", arial_bold14, 2, 0);
				displayString("  Interface is OFF", arial_bold14, 4, 0);
			}
    	}
    	else
    	{
    		displayHighlightedString("        Password        ", arial_bold14, 0, 0);
			switch (currentPosition.lineNumber)
			{
				case 1:
					displayString(" * OFF", arial14, 2, 0);
					displayString("  ON", arial14, 4, 0);
					break;
				case 2:
					displayString("  OFF", arial14, 2, 0);
					displayString(" * ON", arial14, 4, 0);
					break;
				default: break;
			}
    	}
		updateScreen = true;
    }
}
