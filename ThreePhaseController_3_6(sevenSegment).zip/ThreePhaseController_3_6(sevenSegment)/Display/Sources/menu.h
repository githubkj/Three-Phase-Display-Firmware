#ifndef __MENU_H
#define __MENU_H

extern int userInput;
extern _Bool parameterIsSet;

#endif /* __MENU_H */
