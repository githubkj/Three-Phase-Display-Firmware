/* ###################################################################
**     Filename    : main.c
**     Project     : Display
**     Processor   : MKE02Z64VLC4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2016-11-01, 12:57, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**	   Description : This version
**	   				 1. replaces the diagnostic menu with compressor current
**	   				 2. move start up screen (pentair logo and icon all on)
**	   				    into the "void updateDisplayMemory(void)" at main loop
**	   				 3. delete the timer.h and timer.c
**	   				 4. delete delays(before is 1 sec delay) in after D_C_PutVal(SA0)
**	   				    and after RES_SetVal() in OLED_init().
**	   				 5. merge alarm functions into a single function showAlarm(int).
**	   Things Need To do:
**	   				1. Add compressor restart delay
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */

/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "RES.h"
#include "BitIoLdd1.h"
#include "R_W.h"
#include "BitIoLdd2.h"
#include "E_RD.h"
#include "BitIoLdd3.h"
#include "D_C.h"
#include "BitIoLdd4.h"
#include "CS.h"
#include "BitIoLdd5.h"
#include "CI2C1.h"
#include "IntI2cLdd1.h"
#include "TI1_125us.h"
#include "TimerIntLdd1.h"
#include "TU1.h"
#include "Back_Button.h"
#include "BitIoLdd6.h"
#include "OK_Button.h"
#include "BitIoLdd7.h"
#include "Up_Button.h"
#include "BitIoLdd8.h"
#include "Down_Button.h"
#include "BitIoLdd9.h"
#include "Display.h"
#include "TP17.h"
#include "BitIoLdd10.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
/* User includes (#include below this line is not maintained by Processor Expert) */
#include "button.h"
#include "digit.h"
#include "display_UART.h"
#include "displayMemory.h"
#include "icon.h"
#include "mainMenu.h"
#include "menu.h"
#include "OLED.h"
#include "text.h"
#include "screen.h"
#include "serviceMenu.h"
#include "userMenu.h"

/* Defines */

// Firmware & Hardware Versions
#define DU_FIRMWARE_VERSION_MAJOR	'0'
#define DU_FIRMWARE_VERSION_MINOR	'1'
#define DU_HARDWARE_VERSION_MAJOR	'0'
#define DU_HARDWARE_VERSION_MINOR	'1'

/* Global Variables */

// I2C
_Bool I2CIsBusy;

// userInput
int userInput;

// parameter Set Flag
_Bool parameterIsSet;

// Button States
_Bool pressedBack, pressedOK, pressedUp, pressedDown, fourButtonsPressed;

// update screen flag (if set, will triger I2C to send out date in I2CDataToSend[](which contains all the data inside I2CDataBuffer[][]))
_Bool updateScreen;

// update display memory flag (if set, will update the I2CDataBuffer[][]
_Bool displayMemoryNeedsUpdate;

// current location
struct Location currentPosition;

// Update Display Timer
int TI1_updateDisplayMemoryTimer;
_Bool TI1_updateDisplayMemoryTimer_Flag;

// pentair icon timer
_Bool TI1_pentairIconTimer_Flag;
int TI1_pentairIconTimer;

// icon all on timer
_Bool TI1_iconAllOnTimer_Flag;
int TI1_iconAllOnTimer;

// Button Debounce Timer
_Bool TI1_debounceButtonTimer_Flag;
int TI1_debounceButtonTimer;
_Bool debounceDone;

// Button Hold
_Bool TI1_holdButtonTimer_Flag;
int TI1_holdButtonTimer;
_Bool buttonHold;

// alarm Timer
_Bool TI1_alarmTimer_Flag;
int TI1_alarmTimer;

// brightness Timer
_Bool TI1_checkPixelsTimer_Flag;
int TI1_checkPixelsTimer;

// idle Timer
_Bool TI1_idleTimer_Flag;
int TI1_idleTimer, TI1_idleTimer_cnt;

// Probe Timer
_Bool TI1_probeTimer_Flag;
int TI1_probeTimer;

// Validation Screen Timer
_Bool TI1_validationScreenTimer_Flag;
int TI1_validationScreenTimer;

// alarm output
int alarmOutput[NUMBER_OF_ALARMS];

// index in alarmOutput
int alarmOutputIndex, alarmStartPosition;

/* Jason's variables */
bool second_flag = FALSE;
bool prev_second_flag = FALSE;

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
	PE_low_level_init();
	/*** End of Processor Expert internal initialization.                    ***/

	/*****************************************************************************/
	/*                           USER CODE START 								 */
	/*****************************************************************************/

	/* Global variables initialization */

	// I2C
	I2CIsBusy = false;

	// userInput
	userInput = 0;

	// parameter Set Flag
	parameterIsSet = false;

	// pentair icon timer
	TI1_pentairIconTimer_Flag = false;
	TI1_pentairIconTimer = 0;

	// icon all on timer
	TI1_iconAllOnTimer_Flag = false;
	TI1_iconAllOnTimer = 0;

	// Button Debounce Timer
	TI1_debounceButtonTimer_Flag = false;
	TI1_debounceButtonTimer = 0;
	debounceDone = false;

	// Button Hold
	TI1_holdButtonTimer_Flag = false;
	TI1_holdButtonTimer = 0;
	buttonHold = false;

	// current location (initialize to main screen, inlet Temp)
	currentPosition.displayLevel = PENTAIR_ICON_POSITION;
	currentPosition.lineNumber   = INLET_LINENUM;

	// update display memory flag
	displayMemoryNeedsUpdate = true;

	// update screen flag
	updateScreen = true;

	// Update Display Timer
	TI1_updateDisplayMemoryTimer = 0;
	TI1_updateDisplayMemoryTimer_Flag = false;

	// alarm Timer
	TI1_alarmTimer_Flag = false;
	TI1_alarmTimer = 0;

	// brightness Timer
	TI1_checkPixelsTimer_Flag = false;
	TI1_checkPixelsTimer = 0;

	// idle timer
	TI1_idleTimer_Flag = false;
	TI1_idleTimer = 0;

	// Probe Timer
	TI1_probeTimer_Flag = false;
	TI1_probeTimer = 0;

	// Validation Screen Timer
	TI1_validationScreenTimer_Flag = false;
	TI1_validationScreenTimer = 0;

	// alarm output
	for (int i = 0; i < NUMBER_OF_ALARMS; i++)
	{
		alarmOutput[i] = 0;
	}

	// index for alarmOutput, starts at 0;
	alarmOutputIndex = 0;

	// alarm start position
	alarmStartPosition = HIGH_TEMP_ALARM_POSITION;

	/* UART initialization */
	display_uart_init();

	/* OLED display initialization */
	OLED_init();

	/* Button initialization */
	pressedBack = false;
	pressedOK = false;
	pressedUp = false;
	pressedDown = false;
	fourButtonsPressed= false;

	/* Send DU firmware&hardware versions to main board*/
	int displayFirmware = 0;
	displayFirmware += DU_FIRMWARE_VERSION_MAJOR;
	displayFirmware <<= 8;
	displayFirmware += DU_FIRMWARE_VERSION_MINOR;

	int displayHardware = 0;
	displayHardware += DU_HARDWARE_VERSION_MAJOR;
	displayHardware <<= 8;
	displayHardware += DU_HARDWARE_VERSION_MINOR;

	uint16 uart_write_return;
	uart_write_return = display_uart_update(REGISTER, WO_REG_START + DISPLAY_FIRMWARE_REV, false, displayFirmware, DISPLAY_FIRMWARE_REV_F, 0); // 0x3031 = '0''1', means 0.1
	uart_write_return = display_uart_update(REGISTER, WO_REG_START + DISPLAY_HARDWARE_REV, false, displayHardware, DISPLAY_HARDWARE_REV_F, 0);

	clearDisplay();
	_Bool display_uart_run_return;
	int calibriDigit = 123;

    /* MAIN LOOP START */
	while (1)
	{
		display_uart_run_return = display_uart_run();
		scanButton();
		updateDisplayMemory();
		I2CSendData();
	}

	/* MAIN LOOP END */

	/*****************************************************************************/
	/*                           USER CODE END 								     */
	/*****************************************************************************/

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
