#include "button.h"
#include "displayMemory.h"
#include "Back_Button.h"
#include "BitIoLdd6.h"
#include "OK_Button.h"
#include "BitIoLdd7.h"
#include "Up_Button.h"
#include "BitIoLdd8.h"
#include "Down_Button.h"
#include "BitIoLdd9.h"
#include "stdbool.h"
#include "Events.h"
#include "screen.h"

#define IDLE_TIMER_COUNTER_1_MIN				480000
#define IDLE_TIMER_COUNTER_30_SEC				240000

void scanButton(void)
{
	// Back button
	if (!Back_Button_GetVal() && !debounceDone && !TI1_debounceButtonTimer_Flag && !buttonHold && !TI1_holdButtonTimer_Flag)
	{
		TI1_debounceButtonTimer_Flag = true;
	}
	else if (!Back_Button_GetVal() && debounceDone && !buttonHold && !TI1_holdButtonTimer_Flag)
	{
		pressedBack = true;
		debounceDone = false;
		displayMemoryNeedsUpdate = true;
		TI1_holdButtonTimer_Flag = true;
	}
	else if (!Back_Button_GetVal() && pressedBack && !buttonHold)
	{
		pressedBack = false;
	}
	else if (!Back_Button_GetVal() && buttonHold)
	{
		pressedBack = true;
	}
	else
	{
		pressedBack = false;
	}

	// OK Button
	if (!OK_Button_GetVal() && !debounceDone && !TI1_debounceButtonTimer_Flag && !buttonHold && !TI1_holdButtonTimer_Flag)
	{
		TI1_debounceButtonTimer_Flag = true;
	}
	else if (!OK_Button_GetVal() && debounceDone && !buttonHold && !TI1_holdButtonTimer_Flag)
	{
		pressedOK = true;
		debounceDone = false;
		displayMemoryNeedsUpdate = true;
		TI1_holdButtonTimer_Flag = true;
	}
	else if (!OK_Button_GetVal() && pressedOK && !buttonHold)
	{
		pressedOK = false;
	}
	else if (!OK_Button_GetVal() && buttonHold)
	{
		pressedOK = true;
	}
	else
	{
		pressedOK = false;
	}

	// Up button
	if (!Up_Button_GetVal() && !debounceDone && !TI1_debounceButtonTimer_Flag)
	{
		TI1_debounceButtonTimer_Flag = true;
	}
	else if (!Up_Button_GetVal() && debounceDone)
	{
		pressedUp = true;
		debounceDone = false;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		pressedUp = false;
	}

	// Down button
	if (!Down_Button_GetVal() && !debounceDone && !TI1_debounceButtonTimer_Flag)
	{
		TI1_debounceButtonTimer_Flag = true;
	}
	else if (!Down_Button_GetVal() && debounceDone)
	{
		pressedDown = true;
		debounceDone = false;
		displayMemoryNeedsUpdate = true;
	}
	else
	{
		pressedDown = false;
	}

	// Press Four Button: Check Pixels
	if (!Back_Button_GetVal() && !OK_Button_GetVal() && !Up_Button_GetVal() && !Down_Button_GetVal())
	{
		fourButtonsPressed = true;
	}
	else
	{
		fourButtonsPressed = false;
	}

	// Idle
	if (!pressedDown && !pressedUp && !pressedBack && !pressedOK)
	{
		// set the idle timer counter
		if (currentPosition.displayLevel == MAIN_SCREEN_POSITION && currentPosition.lineNumber != INLET_LINENUM)
		{
			TI1_idleTimer_cnt = IDLE_TIMER_COUNTER_30_SEC;
		}
		else
		{
			TI1_idleTimer_cnt = IDLE_TIMER_COUNTER_1_MIN;
		}
		TI1_idleTimer_Flag = true;
		buttonHold = false;
	}
	else
	{
		TI1_idleTimer_Flag = false;
		TI1_idleTimer = 0;
	}
}
