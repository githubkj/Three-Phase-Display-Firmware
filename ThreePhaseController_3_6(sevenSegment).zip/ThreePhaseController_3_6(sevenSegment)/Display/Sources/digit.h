#ifndef __DIGIT_H
#define __DIGIT_H

/*****************************************************************************/
/*                           digit24_48 								     */
/*                           Digit on main screen 						     */
/*****************************************************************************/
/* width = 24 columns ; height = 48 rows = 6(pages)x8(row/page) */
extern const char digit24_48[];
extern const char digit_courier7x14[];
extern const char decimal_point [];
extern const char negative_sign[];

/* Function Prototypes */

	void showDigit(const char font[], unsigned char digit, unsigned char page, unsigned char column);
	void showHighlightedDigit(const char digit[], unsigned char num, unsigned char page, unsigned char column);
	void clearDigit(unsigned char page, unsigned char column);
	void showNumber(const char digit[], int number, unsigned char page, unsigned char column);
	void showSmallDigit(const char font[], unsigned char digit, unsigned char page, unsigned char column);
	void showSmallHighlightedDigit(const char digit[], unsigned char num, unsigned char page, unsigned char column);
	void showSmallNumber(const char digit[], int number, unsigned char page, unsigned char column);
	void clearSmallDigit(unsigned char page, unsigned char column);

#endif /* __DIGIT_H */
