#ifndef __DISPLAY_MEMORY_H
#define __DISPLAY_MEMORY_H

extern int userInput;
extern _Bool parameterIsSet;
extern _Bool updateDisplayMemory;
extern _Bool refreshScreen;

void checkDisplayMemory(void);

#endif /* __DISPLAY_MEMORY_H */
