/* ###################################################################
**     Filename    : main.c
**     Project     : Display
**     Processor   : MKE02Z64VLC4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2016-11-01, 12:57, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**	   Description : This version uses the calibri light
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */

/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "RES.h"
#include "BitIoLdd1.h"
#include "R_W.h"
#include "BitIoLdd2.h"
#include "E_RD.h"
#include "BitIoLdd3.h"
#include "D_C.h"
#include "BitIoLdd4.h"
#include "CS.h"
#include "BitIoLdd5.h"
#include "CI2C1.h"
#include "IntI2cLdd1.h"
#include "TI1_125us.h"
#include "TimerIntLdd1.h"
#include "TU1.h"
#include "Back_Button.h"
#include "BitIoLdd6.h"
#include "OK_Button.h"
#include "BitIoLdd7.h"
#include "Up_Button.h"
#include "BitIoLdd8.h"
#include "Down_Button.h"
#include "BitIoLdd9.h"
#include "Display.h"
#include "TP17.h"
#include "BitIoLdd10.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
/* User includes (#include below this line is not maintained by Processor Expert) */
#include "button.h"
#include "digit.h"
#include "display_UART.h"
#include "displayMemory.h"
#include "displayPosition.h"
#include "icon.h"
#include "OLED.h"
#include "text.h"
#include "stdbool.h"

// Firmware & Hardware Versions
#define DU_FIRMWARE_VERSION_MAJOR	'0'
#define DU_FIRMWARE_VERSION_MINOR	'3'
#define DU_HARDWARE_VERSION_MAJOR	'0'
#define DU_HARDWARE_VERSION_MINOR	'1'

/* Global Variables */

_Bool refreshScreen;

_Bool updateDisplayMemory;

_Bool updateDisplayPosition;

// I2C
_Bool I2CIsBusy;

// userInput
int userInput;

// parameter Set Flag
_Bool parameterIsSet;

// Button States
_Bool pressedBack;
_Bool pressedOK;
_Bool pressedUp;
_Bool pressedDown;
_Bool fourButtonsPressed;

_Bool releasedBack;
_Bool releasedOK;
_Bool releasedUp;
_Bool releasedDown;

_Bool heldBack;
_Bool heldOK;
_Bool heldUp;
_Bool heldDown;

// update screen flag (if set, will triger I2C to send out date in I2CDataToSend[](which contains all the data inside I2CDataBuffer[][]))
_Bool updateScreen;

// current location
struct Location currentPosition;

// pentair icon timer
_Bool TI1_pentairIconTimer_Flag;
int TI1_pentairIconTimer;

// icon all on timer
_Bool TI1_iconAllOnTimer_Flag;
int TI1_iconAllOnTimer;

/* Update Screen Timer */
_Bool TI1_updateScreenTimerIsOn;
int TI1_updateScreenTimer;
_Bool updateScreenTimerDone;
int updateScreenRate;

// Back button
_Bool TI1_backButtonTimerIsOn;
int TI1_backButtonTimer;

// OK Button
_Bool TI1_OKButtonTimerIsOn;
int TI1_OKButtonTimer;

// Up Button
_Bool TI1_upButtonTimerIsOn;
int TI1_upButtonTimer;
_Bool heldUp;

// Down Button
_Bool TI1_downButtonTimerIsOn;
int TI1_downButtonTimer;
_Bool heldDown;
_Bool releasedDown;

// alarm Timer
_Bool TI1_alarmTimer_Flag;
int TI1_alarmTimer;

// brightness Timer
_Bool TI1_checkPixelsTimer_Flag;
int TI1_checkPixelsTimer;

// idle Timer
_Bool TI1_idleTimer_Flag;
int TI1_idleTimer, TI1_idleTimer_cnt;

// Probe Timer
_Bool TI1_probeTimer_Flag;
int TI1_probeTimer;

// Validation Screen Timer
_Bool TI1_validationScreenTimer_Flag;
int TI1_validationScreenTimer;

// alarm output
int alarmOutput[NUMBER_OF_ALARMS];

// index in alarmOutput
int alarmOutputIndex, alarmStartPosition;

/* Jason's variables */
bool second_flag = FALSE;
bool prev_second_flag = FALSE;

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
	PE_low_level_init();
	/*** End of Processor Expert internal initialization.                    ***/

	/*****************************************************************************/
	/*                           USER CODE START 								 */
	/*****************************************************************************/

	/*---------------   PART I: Global Variables Initializations   ---------------*/

	/************** Communication: UART + I2C **************/

	// I2C
	I2CIsBusy = false;

	// UART
	display_uart_init();
	_Bool display_uart_run_return;

	/* Send DU firmware&hardware versions to main board*/
	int displayFirmware = 0;
	displayFirmware += DU_FIRMWARE_VERSION_MAJOR;
	displayFirmware <<= 8;
	displayFirmware += DU_FIRMWARE_VERSION_MINOR;

	int displayHardware = 0;
	displayHardware += DU_HARDWARE_VERSION_MAJOR;
	displayHardware <<= 8;
	displayHardware += DU_HARDWARE_VERSION_MINOR;

	uint16 uart_write_return;
	uart_write_return = display_uart_update(REGISTER, WO_REG_START + DISPLAY_FIRMWARE_REV, false, displayFirmware, DISPLAY_FIRMWARE_REV_F, 0); // 0x3031 = '0''1', means 0.1
	uart_write_return = display_uart_update(REGISTER, WO_REG_START + DISPLAY_HARDWARE_REV, false, displayHardware, DISPLAY_HARDWARE_REV_F, 0);

	/************** User Input: Buttons **************/

	// Button States
	pressedBack = false;
	pressedOK = false;
	pressedUp = false;
	pressedDown = false;
	fourButtonsPressed= false;
	releasedBack = false;
	releasedOK = false;
	releasedUp = false;
	releasedDown = false;
	heldBack = false;
	heldOK = false;
	heldUp = false;
	heldDown = false;

	// Back button
	TI1_backButtonTimerIsOn = false;
	TI1_backButtonTimer = 0;

	// OK Button
	TI1_OKButtonTimerIsOn = false;
	TI1_OKButtonTimer = 0;

	// Up Button
	TI1_upButtonTimerIsOn = false;
	TI1_upButtonTimer = 0;

	// Down Button
	TI1_downButtonTimerIsOn = false;
	TI1_downButtonTimer = 0;

	/************** Screen: OLED display **************/

	// userInput
	userInput = 0;

	// parameter Set Flag
	parameterIsSet = false;

	// pentair icon timer
	TI1_pentairIconTimer_Flag = false;
	TI1_pentairIconTimer = 0;

	// icon all on timer
	TI1_iconAllOnTimer_Flag = false;
	TI1_iconAllOnTimer = 0;

	// Update Screen Timer
	TI1_updateScreenTimerIsOn = false;
	TI1_updateScreenTimer = 0;
	updateScreenTimerDone = false;
	updateScreenRate = 4000;

	// update screen flag
	updateScreen = true;

	// check pixels Timer
	TI1_checkPixelsTimer_Flag = false;
	TI1_checkPixelsTimer = 0;

	// idle timer
	TI1_idleTimer_Flag = false;
	TI1_idleTimer = 0;

	// Probe Timer
	TI1_probeTimer_Flag = false;
	TI1_probeTimer = 0;

	// Validation Screen Timer
	TI1_validationScreenTimer_Flag = false;
	TI1_validationScreenTimer = 0;

	// Alarms

	// alarm Timer
	TI1_alarmTimer_Flag = false;
	TI1_alarmTimer = 0;

	// alarm output
	for (int i = 0; i < NUMBER_OF_ALARMS; i++)
	{
		alarmOutput[i] = 0;
	}

	// index for alarmOutput, starts at 0;
	alarmOutputIndex = 0;

	// alarm start position
	alarmStartPosition = HIGH_TEMP_ALARM_POSITION;

	/* OLED display initialization */
	OLED_init();

	// startup location
	currentPosition.displayLevel = PENTAIR_ICON_POSITION;
	currentPosition.lineNumber   = INLET_LINENUM;

	updateDisplayMemory = true;
	refreshScreen = true;
	updateDisplayPosition = false;
/* The following two variables are for different font demo */
//	_Bool lightFont = true;
//	_Bool upswitch = true;

	/*----------------------   PART II: MAIN LOOP START  ----------------------*/
	while (1)
	{
		/************** User Input: Buttons **************/
		scanButton();

		/************** Positions **************/
		checkDisplayPosition();

		/************** OLED display Memory **************/
		checkDisplayMemory();

		/************** Communication: UART + I2C **************/
		display_uart_run_return = display_uart_run();
		I2CSendData();

		/* The following is for different font demo */
/*
		if (pressedUp && !heldUp)
		{
			if (updateScreenTimerDone)
			{
				userInput += 1;
				updateScreen = true;
				updateScreenTimerDone = false;
			}
			else
			{
				if (!TI1_updateScreenTimerIsOn)
				{
					updateScreenRate = 4000;
					TI1_updateScreenTimerIsOn = true;
				}
			}
		}
		else if (releasedUp)
		{
			releasedUp = false;
			if (upswitch)
			{
				upswitch = false;
			}else{
				upswitch = true;
			}
			updateScreen = true;
		}
		else if (heldUp)
		{
			if (updateScreenTimerDone)
			{
				userInput += 1;
				updateScreen = true;
				updateScreenTimerDone = false;
			}
			else
			{
				if (!TI1_updateScreenTimerIsOn)
				{
					updateScreenRate = 500;
					TI1_updateScreenTimerIsOn = true;
				}
			}
		}

		if (pressedDown && !heldDown)
		{
			if (updateScreenTimerDone)
			{
				userInput -= 1;
				updateScreen = true;
				updateScreenTimerDone = false;
			}
			else
			{
				if (!TI1_updateScreenTimerIsOn)
				{
					updateScreenRate = 4000;
					TI1_updateScreenTimerIsOn = true;
				}
			}
		}
		else if (heldDown)
		{
			if (updateScreenTimerDone)
			{
				userInput -= 1;
				updateScreen = true;
				updateScreenTimerDone = false;
			}
			else
			{
				if (!TI1_updateScreenTimerIsOn)
				{
					updateScreenRate = 500;
					TI1_updateScreenTimerIsOn = true;
				}
			}
		}

		if (pressedBack)
		{
			pressedBack = false;
			if (lightFont)
			{
				lightFont = false;
			}
			else
			{
				lightFont = true;
			}
			clearDisplay();
			updateScreen = true;
		}
		if (lightFont)
		{
			showIntegerLeftAligned(digitCalibriLight5x30, userInput, 5, 30, 3, 20);
			if (upswitch)
			{
				displayString(" *", arial14, 0, 5);
			}else{
				displayString(" +", arial14, 0, 5);
			}
		}
		else
		{
			showIntegerRightAligned(digitCalibriLight5x30, userInput, 5, 30, 3, 110);
		}
*/
	}

	/* MAIN LOOP END */

	/*****************************************************************************/
	/*                           USER CODE END 								     */
	/*****************************************************************************/

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
