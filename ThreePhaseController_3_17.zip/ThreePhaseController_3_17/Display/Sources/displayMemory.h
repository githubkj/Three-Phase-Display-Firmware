#ifndef __DISPLAY_MEMORY_H
#define __DISPLAY_MEMORY_H

extern int userInput;
extern _Bool parameterIsSet;
extern _Bool updateDisplayMemory;
extern _Bool refreshScreen;

void checkDisplayMemory(void);

void mainScreenDisplayMemory(void);
void mainMenuDisplayMemory(void);
void userInterfaceDisplayMemory(void);
void systemInterfaceDisplayMemory(void);
void enterPasswordDisplayMemory(void);
void showVersionNumber(int versionNumber, char page, char col);
void aboutMenuDisplayMemory(void);

void alarmDisplayMemory(int alarmPosition);

void coolingSetPointDisplayMemory(void);
void coolingDifferentialDisplayMemory(void);
void heatingSetPointDisplayMemory(void);
void heatingDifferentialDisplayMemory(void);
void highTempAlarmDisplayMemory(void);
void lowTempAlarmDisplayMemory(void);
void tempScaleDisplayMemory(void);
void hysteresisDisplayMemory(void);
void passwordDisplayMemory(void);
void languageDisplayMemory(void);

void doorSmokeAlarmDisplayMemory(void);
void disableSwitchAlarmDisplayMemory(void);
void alarmRelayOutputDisplayMemory(void);
void compressorRestartDelayDisplayMemory(void);
void compressorCurrentDisplayMemory(void);
void systemSettingsDisplayMemory(void);
void currentLimitSettingsDisplayMemory(void);
void malfDeactivateDisplayMemory(void);
void malfActivateDisplayMemory(void);
void hpcFanOnDisplayMemory(void);
void hpcFanOffDisplayMemory(void);

void turnOnAllPixels(void);

void showWorkingStatus1(void);
void showWorkingStatus2(void);
void showDegree(unsigned char page, unsigned char column);
void showTempReading(int tempReading, unsigned char page, unsigned char column);
void showTimer(const char font[], unsigned char minute, unsigned char second, unsigned char heightInPages, unsigned char widthInRows, unsigned char page, unsigned char column);

#endif /* __DISPLAY_MEMORY_H */
