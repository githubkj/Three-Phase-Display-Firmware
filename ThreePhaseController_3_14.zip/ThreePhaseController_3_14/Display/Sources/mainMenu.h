#ifndef __MAIN_MENU_H
#define __MAIN_MENU_H

/* Function Prototypes */
void mainMenu(void);
void enterPassword(void);
void userInterfaceMenu(void);
void systemInterfaceMenu(void);
void showVersionNumber(int versionNumber, char page, char col);
void aboutMenu(void);

//void changeFont(void);

#endif /* __MAIN_MENU_H */
