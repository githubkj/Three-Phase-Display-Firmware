#ifndef __BUTTON_H
#define __BUTTON_H

#include "stdbool.h"

#define BUTTON_HELD_REFRESH_TIME		800 // Every 100 ms
/* Global Variables */

	extern _Bool pressedBack;
	extern _Bool pressedOK;
	extern _Bool pressedUp;
	extern _Bool pressedDown;
	extern _Bool fourButtonsPressed;

	extern _Bool releasedBack;
	extern _Bool releasedOK;
	extern _Bool releasedUp;
	extern _Bool releasedDown;

	extern _Bool heldBack;
	extern _Bool heldOK;
	extern _Bool heldUp;
	extern _Bool heldDown;
/* Function Prototype */

	void scanButton(void);

#endif
